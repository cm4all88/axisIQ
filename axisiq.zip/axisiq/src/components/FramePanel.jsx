import { useState, useEffect, useRef } from 'react'
import { useMachineStore } from '../store'
import './FramePanel.css'

const api = window.axisiq

// ── Bounding box parser ────────────────────────────────────────────────────────

function parseBoundingBox(lines) {
  let minX = Infinity, maxX = -Infinity
  let minY = Infinity, maxY = -Infinity
  let px = 0, py = 0
  let absolute = true

  for (const raw of lines) {
    const line = raw.split(';')[0].toUpperCase().trim()
    if (!line) continue
    if (line.includes('G90')) { absolute = true; continue }
    if (line.includes('G91')) { absolute = false; continue }

    // Skip non-motion lines
    if (!line.match(/^[Gg][0123]/)) continue

    const xm = line.match(/X(-?\d+\.?\d*)/)
    const ym = line.match(/Y(-?\d+\.?\d*)/)
    if (!xm && !ym) continue

    const nx = xm ? (absolute ? parseFloat(xm[1]) : px + parseFloat(xm[1])) : px
    const ny = ym ? (absolute ? parseFloat(ym[1]) : py + parseFloat(ym[1])) : py

    minX = Math.min(minX, nx); maxX = Math.max(maxX, nx)
    minY = Math.min(minY, ny); maxY = Math.max(maxY, ny)
    px = nx; py = ny
  }

  if (minX === Infinity) return null
  return {
    minX, maxX, minY, maxY,
    width:  parseFloat((maxX - minX).toFixed(3)),
    height: parseFloat((maxY - minY).toFixed(3)),
  }
}

// ── G-code generators ──────────────────────────────────────────────────────────

function genRouterBBox({ bbox, margin, clearance, speed, passes }) {
  const x1 = (bbox.minX - margin).toFixed(3)
  const y1 = (bbox.minY - margin).toFixed(3)
  const x2 = (bbox.maxX + margin).toFixed(3)
  const y2 = (bbox.maxY + margin).toFixed(3)
  const F  = Math.round(speed * 60)
  const Z  = clearance.toFixed(3)
  const lines = [
    '; AxisIQ Frame — Bounding Box',
    `; ${(bbox.width + margin*2).toFixed(1)} × ${(bbox.height + margin*2).toFixed(1)}mm  margin ${margin}mm  Z${clearance}mm`,
    'G21 G90',
    `G0 Z${Z}`,
  ]
  for (let p = 0; p < passes; p++) {
    lines.push(`; Pass ${p + 1}`)
    lines.push(`G0 X${x1} Y${y1}`)
    lines.push(`G1 X${x2} F${F}`)
    lines.push(`G1 Y${y2}`)
    lines.push(`G1 X${x1}`)
    lines.push(`G1 Y${y1}`)
    if (p < passes - 1) lines.push('G4 P1.5')
  }
  lines.push(`G0 Z${Z}`)
  lines.push('G0 X0.000 Y0.000')
  lines.push('M30')
  return lines.join('\n')
}

function genRouterCorners({ bbox, margin, clearance, speed }) {
  const x1 = (bbox.minX - margin).toFixed(3)
  const y1 = (bbox.minY - margin).toFixed(3)
  const x2 = (bbox.maxX + margin).toFixed(3)
  const y2 = (bbox.maxY + margin).toFixed(3)
  const F  = Math.round(speed * 60)
  const Z  = clearance.toFixed(3)
  return [
    '; AxisIQ Frame — Corners',
    `; BL→BR→TR→TL  margin ${margin}mm  Z${clearance}mm`,
    'G21 G90',
    `G0 Z${Z}`,
    `G0 X${x1} Y${y1}`, 'G4 P2',  // BL
    `G0 X${x2} Y${y1}`, 'G4 P2',  // BR
    `G0 X${x2} Y${y2}`, 'G4 P2',  // TR
    `G0 X${x1} Y${y2}`, 'G4 P2',  // TL
    `G0 X${x1} Y${y1}`, 'G4 P2',  // back to BL
    `G0 Z${Z}`,
    'G0 X0.000 Y0.000',
    'M30',
  ].join('\n')
}

function genRouterActual({ gcodeLines, clearance, speed }) {
  const Z  = clearance.toFixed(3)
  const F  = Math.round(speed * 60)
  const lines = [
    '; AxisIQ Frame — Actual Path (clearance height)',
    `; Running full path at Z${clearance}mm, no cutting`,
    'G21 G90',
    `G0 Z${Z}`,
    '',
  ]
  let px = 0, py = 0, absolute = true

  for (const raw of gcodeLines) {
    const l = raw.split(';')[0].toUpperCase().trim()
    if (!l) continue
    if (l.includes('G90')) { absolute = true; continue }
    if (l.includes('G91')) { absolute = false; continue }
    if (!l.match(/^[Gg][0123]/)) continue

    const xm = l.match(/X(-?\d+\.?\d*)/)
    const ym = l.match(/Y(-?\d+\.?\d*)/)
    if (!xm && !ym) continue

    const nx = xm ? (absolute ? parseFloat(xm[1]) : px + parseFloat(xm[1])) : px
    const ny = ym ? (absolute ? parseFloat(ym[1]) : py + parseFloat(ym[1])) : py

    // All moves become rapids at clearance height (no Z depth)
    lines.push(`G0 X${nx.toFixed(3)} Y${ny.toFixed(3)}`)
    px = nx; py = ny
  }

  lines.push(`G0 Z${Z}`)
  lines.push('G0 X0.000 Y0.000')
  lines.push('M30')
  return lines.join('\n')
}

function genLaserBBox({ bbox, margin, power, speed, passes }) {
  const S  = Math.round(power / 100 * 1000)
  const x1 = (bbox.minX - margin).toFixed(3)
  const y1 = (bbox.minY - margin).toFixed(3)
  const x2 = (bbox.maxX + margin).toFixed(3)
  const y2 = (bbox.maxY + margin).toFixed(3)
  const F  = Math.round(speed * 60)
  const lines = [
    '; AxisIQ Frame — Laser Bounding Box',
    `; ${(bbox.width + margin*2).toFixed(1)} × ${(bbox.height + margin*2).toFixed(1)}mm  ${power}% power`,
    'G21 G90',
    '$32=1',
    'M4 S0',
  ]
  for (let p = 0; p < passes; p++) {
    lines.push(`; Pass ${p + 1}`)
    lines.push(`G0 X${x1} Y${y1}`)
    lines.push(`M4 S${S}`)
    lines.push(`G1 X${x2} F${F}`)
    lines.push(`G1 Y${y2}`)
    lines.push(`G1 X${x1}`)
    lines.push(`G1 Y${y1}`)
    lines.push('M4 S0')
    if (p < passes - 1) lines.push('G4 P2')
  }
  lines.push('M5')
  lines.push('M30')
  return lines.join('\n')
}

function genLaserCorners({ bbox, margin, power, speed }) {
  const S  = Math.round(power / 100 * 1000)
  const x1 = (bbox.minX - margin).toFixed(3)
  const y1 = (bbox.minY - margin).toFixed(3)
  const x2 = (bbox.maxX + margin).toFixed(3)
  const y2 = (bbox.maxY + margin).toFixed(3)
  const F  = Math.round(speed * 60)
  const corners = [[x1,y1,'BL'],[x2,y1,'BR'],[x2,y2,'TR'],[x1,y2,'TL'],[x1,y1,'BL']]
  const lines = [
    '; AxisIQ Frame — Laser Corners',
    `; ${power}% power  ${speed}mm/s  margin ${margin}mm`,
    'G21 G90', '$32=1', 'M4 S0',
  ]
  for (const [x, y, label] of corners) {
    lines.push(`G0 X${x} Y${y}`, `M4 S${S}`, `G4 P1.5`, 'M4 S0', 'G4 P1')
  }
  lines.push('M5', 'M30')
  return lines.join('\n')
}

function genLaserActual({ gcodeLines, power, speed }) {
  const S  = Math.round(power / 100 * 1000)
  const F  = Math.round(speed * 60)
  const lines = [
    '; AxisIQ Frame — Laser Actual Path',
    `; Real path outline at ${power}% power`,
    'G21 G90', '$32=1', 'M4 S0', '',
  ]
  let px = 0, py = 0, absolute = true

  for (const raw of gcodeLines) {
    const l = raw.split(';')[0].toUpperCase().trim()
    if (!l) continue
    if (l.includes('G90')) { absolute = true; continue }
    if (l.includes('G91')) { absolute = false; continue }
    if (!l.match(/^[Gg][0123]/)) continue

    const xm = l.match(/X(-?\d+\.?\d*)/)
    const ym = l.match(/Y(-?\d+\.?\d*)/)
    if (!xm && !ym) continue

    const nx = xm ? (absolute ? parseFloat(xm[1]) : px + parseFloat(xm[1])) : px
    const ny = ym ? (absolute ? parseFloat(ym[1]) : py + parseFloat(ym[1])) : py

    lines.push(`G0 X${nx.toFixed(3)} Y${ny.toFixed(3)}`)
    lines.push(`M4 S${S}`)
    lines.push(`G4 P0.1`)
    lines.push('M4 S0')

    px = nx; py = ny
  }

  lines.push('M5', 'M30')
  return lines.join('\n')
}

// ── Canvas preview ─────────────────────────────────────────────────────────────

function FrameCanvas({ bbox, margin, machineType, mode }) {
  const ref = useRef(null)

  useEffect(() => {
    const canvas = ref.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const W = canvas.width, H = canvas.height

    ctx.clearRect(0, 0, W, H)
    ctx.fillStyle = '#17171a'
    ctx.fillRect(0, 0, W, H)

    if (!bbox) {
      ctx.fillStyle = '#56544e'
      ctx.font = '11px Inter Tight, sans-serif'
      ctx.textAlign = 'center'
      ctx.fillText('No file loaded', W / 2, H / 2)
      return
    }

    const pad = 20
    const fw = bbox.width + margin * 2
    const fh = bbox.height + margin * 2
    const scale = Math.min((W - pad * 2) / fw, (H - pad * 2) / fh) * 0.85

    const ox = W / 2 - fw * scale / 2
    const oy = H / 2 - fh * scale / 2

    // Work area hint
    ctx.strokeStyle = '#27272c'
    ctx.lineWidth = 1
    ctx.strokeRect(4, 4, W - 8, H - 8)

    // Part bounding box (actual)
    const bx = ox + margin * scale
    const by = oy + margin * scale
    const bw = bbox.width * scale
    const bh = bbox.height * scale

    ctx.strokeStyle = '#36363e'
    ctx.lineWidth = 1
    ctx.setLineDash([3, 3])
    ctx.strokeRect(bx, by, bw, bh)
    ctx.setLineDash([])

    // Frame rectangle (with margin)
    const amber  = '#f0a030'
    const laserC = '#60a0e0'
    const color  = machineType === 'co2' ? laserC : amber

    ctx.strokeStyle = color
    ctx.lineWidth = 2
    ctx.strokeRect(ox, oy, fw * scale, fh * scale)

    // Corner markers
    const cs = 8
    ctx.fillStyle = color
    const corners = [
      [ox, oy], [ox + fw*scale, oy],
      [ox + fw*scale, oy + fh*scale], [ox, oy + fh*scale],
    ]
    for (const [cx, cy] of corners) {
      ctx.fillRect(cx - cs/2, cy - cs/2, cs, cs)
    }

    // Arrow direction (clockwise)
    const mx = ox + fw * scale / 2
    const topY = oy - 10
    if (topY > 4) {
      ctx.fillStyle = color
      ctx.font = '10px Inter Tight, sans-serif'
      ctx.textAlign = 'center'
      ctx.fillText('→', mx, oy + 14)
    }

    // Dimensions
    ctx.fillStyle = '#8e8c84'
    ctx.font = '9px JetBrains Mono, monospace'
    ctx.textAlign = 'center'
    ctx.fillText(fw.toFixed(1) + 'mm', ox + fw * scale / 2, oy + fh * scale + 14)
    ctx.textAlign = 'right'
    ctx.fillText(fh.toFixed(1) + 'mm', ox - 4, oy + fh * scale / 2 + 4)

    // Mode label
    ctx.fillStyle = color
    ctx.font = '9px Inter Tight, sans-serif'
    ctx.textAlign = 'left'
    ctx.fillText(
      mode === 'bbox' ? 'bounding box' : mode === 'corners' ? 'corners' : 'actual path',
      ox + 3, oy + fh * scale - 3
    )

  }, [bbox, margin, machineType, mode])

  return <canvas ref={ref} width={220} height={160} className="frame-canvas" />
}

// ── Main component ─────────────────────────────────────────────────────────────

export default function FramePanel({ onFramePassed }) {
  const {
    connected, gcodeLines, machineType, addLog,
  } = useMachineStore()

  const [mode, setMode]         = useState('bbox')
  const [margin, setMargin]     = useState(2)
  const [passes, setPasses]     = useState(1)

  // Router settings
  const [clearance, setClearance] = useState(5)
  const [frameSpeed, setFrameSpeed] = useState(80) // mm/s

  // Laser settings
  const [framePower, setFramePower] = useState(3)   // %
  const [laserFrameSpeed, setLaserFrameSpeed] = useState(200) // mm/s

  const [status, setStatus]     = useState('idle')  // idle | running | passed | failed
  const [showCode, setShowCode] = useState(false)
  const [bbox, setBbox]         = useState(null)

  // Parse bounding box whenever gcode changes
  useEffect(() => {
    if (!gcodeLines || gcodeLines.length === 0) {
      setBbox(null)
      setStatus('idle')
      return
    }
    const b = parseBoundingBox(gcodeLines)
    setBbox(b)
    setStatus('idle')
  }, [gcodeLines])

  function getCode() {
    if (!bbox) return ''
    const isLaser = machineType === 'co2'

    if (isLaser) {
      if (mode === 'bbox')     return genLaserBBox({ bbox, margin, power: framePower, speed: laserFrameSpeed, passes })
      if (mode === 'corners')  return genLaserCorners({ bbox, margin, power: framePower, speed: laserFrameSpeed })
      if (mode === 'actual')   return genLaserActual({ gcodeLines, power: framePower, speed: laserFrameSpeed })
    } else {
      if (mode === 'bbox')     return genRouterBBox({ bbox, margin, clearance, speed: frameSpeed, passes })
      if (mode === 'corners')  return genRouterCorners({ bbox, margin, clearance, speed: frameSpeed })
      if (mode === 'actual')   return genRouterActual({ gcodeLines, clearance, speed: frameSpeed })
    }
    return ''
  }

  async function runFrame() {
    if (!connected || !bbox) return
    const code = getCode()
    if (!code) return

    setStatus('running')
    addLog({ type: 'info', text: `Frame started: ${mode} mode, ${margin}mm margin`, time: Date.now() })

    const lines = code.split('\n').filter(l => l.trim() && !l.trim().startsWith(';'))
    await api?.startStream(lines)

    // Listen for stream done — in real app this comes via IPC
    // For now, simulate completion after estimated time
    const estSecs = mode === 'corners'
      ? 12
      : Math.round((bbox.width + bbox.height) * 2 * passes / (machineType === 'co2' ? laserFrameSpeed : frameSpeed)) + 3

    setTimeout(() => {
      setStatus('passed')
      addLog({ type: 'info', text: 'Frame complete — path confirmed', time: Date.now() })
      if (onFramePassed) onFramePassed()
    }, estSecs * 1000)
  }

  const isLaser   = machineType === 'co2'
  const frameColor = isLaser ? 'var(--blue)' : 'var(--amber)'
  const accentDim  = isLaser ? 'rgba(96,152,208,0.12)' : 'var(--amber-dim)'
  const accentBorder = isLaser ? 'rgba(96,152,208,0.4)' : 'var(--amber-2)'

  return (
    <div
      className={`frame-panel ${status === 'passed' ? 'frame-passed' : status === 'running' ? 'frame-running' : ''}`}
      style={{ '--fc': frameColor, '--fd': accentDim, '--fb': accentBorder }}
    >
      {/* Header */}
      <div className="frame-header">
        <div className="frame-header-left">
          <span className="frame-title">Frame Check</span>
          {bbox ? (
            <span className="frame-bbox-dims mono">
              {bbox.width.toFixed(1)} × {bbox.height.toFixed(1)} mm
            </span>
          ) : (
            <span className="frame-no-file">Load a file first</span>
          )}
        </div>
        <div className="frame-status-pill">
          {status === 'idle'    && <span className="fp fp-idle">Not run</span>}
          {status === 'running' && <span className="fp fp-run">◈ Running…</span>}
          {status === 'passed'  && <span className="fp fp-pass">✓ Passed</span>}
          {status === 'failed'  && <span className="fp fp-fail">✗ Failed</span>}
        </div>
      </div>

      <div className="frame-body">
        <div className="frame-left">

          {/* Mode */}
          <div className="frame-section">
            <span className="frame-label">Mode</span>
            <div className="frame-modes">
              {[
                ['bbox',    '□ Bounding Box',  'Rectangle around all moves. Fastest.'],
                ['corners', '⊹ Corners Only',  'Jogs to each corner and pauses 1.5s. Very fast check.'],
                ['actual',  '◈ Actual Path',   'Traces the real path outline. Most accurate.'],
              ].map(([id, label, desc]) => (
                <button
                  key={id}
                  className={`frame-mode-btn ${mode === id ? 'frame-mode-active' : ''}`}
                  onClick={() => setMode(id)}
                >
                  <span className="fmb-label">{label}</span>
                  <span className="fmb-desc">{desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Settings */}
          <div className="frame-settings">
            <div className="frame-field">
              <label>Margin</label>
              <div className="frame-input-row">
                <input
                  type="number" min={0} max={20} step={0.5} value={margin}
                  onChange={e => setMargin(Number(e.target.value))}
                />
                <span className="frame-unit">mm</span>
              </div>
            </div>

            {mode !== 'corners' && (
              <div className="frame-field">
                <label>Passes</label>
                <div className="frame-input-row">
                  <input
                    type="number" min={1} max={5} step={1} value={passes}
                    onChange={e => setPasses(Number(e.target.value))}
                  />
                  <span className="frame-unit">×</span>
                </div>
              </div>
            )}

            {/* Router specific */}
            {!isLaser && (
              <>
                <div className="frame-field">
                  <label>Clearance Z</label>
                  <div className="frame-input-row">
                    <input
                      type="number" min={1} max={50} step={1} value={clearance}
                      onChange={e => setClearance(Number(e.target.value))}
                    />
                    <span className="frame-unit">mm</span>
                  </div>
                </div>
                <div className="frame-field">
                  <label>Speed</label>
                  <div className="frame-input-row">
                    <input
                      type="number" min={10} max={200} step={5} value={frameSpeed}
                      onChange={e => setFrameSpeed(Number(e.target.value))}
                    />
                    <span className="frame-unit">mm/s</span>
                  </div>
                </div>
              </>
            )}

            {/* Laser specific */}
            {isLaser && (
              <>
                <div className="frame-field">
                  <label>Power</label>
                  <div className="frame-input-row">
                    <input
                      type="number" min={1} max={10} step={1} value={framePower}
                      onChange={e => setFramePower(Number(e.target.value))}
                    />
                    <span className="frame-unit">%</span>
                  </div>
                </div>
                <div className="frame-field">
                  <label>Speed</label>
                  <div className="frame-input-row">
                    <input
                      type="number" min={50} max={500} step={10} value={laserFrameSpeed}
                      onChange={e => setLaserFrameSpeed(Number(e.target.value))}
                    />
                    <span className="frame-unit">mm/s</span>
                  </div>
                </div>
              </>
            )}
          </div>

          {isLaser && framePower <= 5 && (
            <div className="frame-hint">
              💡 {framePower}% is visible on most materials without marking. Increase to 8–10% on dark materials.
            </div>
          )}

          {!isLaser && (
            <div className="frame-hint">
              Router traces at Z{clearance}mm — above all clamps and fixtures. Adjust if your setup is taller.
            </div>
          )}

          {/* Actions */}
          <div className="frame-actions">
            <button
              className="frame-run-btn"
              disabled={!connected || !bbox || status === 'running'}
              onClick={runFrame}
              style={{ opacity: !bbox ? 0.38 : 1 }}
            >
              {status === 'running'
                ? '◈ Running…'
                : status === 'passed'
                  ? '✓ Re-run Frame'
                  : '▶ Run Frame'}
            </button>

            {status === 'passed' && (
              <button
                className="frame-reset-btn"
                onClick={() => setStatus('idle')}
              >
                Reset
              </button>
            )}
          </div>

          <button
            className="frame-code-toggle"
            disabled={!bbox}
            onClick={() => setShowCode(v => !v)}
          >
            {showCode ? 'Hide' : 'Preview'} G-code
          </button>

        </div>

        {/* Canvas preview */}
        <div className="frame-right">
          <span className="frame-label" style={{ marginBottom: 6, display: 'block' }}>Preview</span>
          <FrameCanvas
            bbox={bbox}
            margin={margin}
            machineType={machineType}
            mode={mode}
          />
          {bbox && (
            <div className="frame-dim-legend">
              <div className="fdl-row">
                <span className="fdl-swatch" style={{ background: 'var(--fc)' }} />
                <span>Frame ({(bbox.width + margin*2).toFixed(1)} × {(bbox.height + margin*2).toFixed(1)}mm)</span>
              </div>
              <div className="fdl-row">
                <span className="fdl-swatch fdl-dashed" />
                <span>Part bounds ({bbox.width.toFixed(1)} × {bbox.height.toFixed(1)}mm)</span>
              </div>
              {margin > 0 && (
                <div className="fdl-row" style={{ color: 'var(--t3)' }}>
                  <span className="fdl-swatch" style={{ background: 'transparent' }} />
                  <span>{margin}mm margin each side</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* G-code preview */}
      {showCode && bbox && (
        <div className="frame-code">
          {getCode().split('\n').map((line, i) => (
            <div key={i} style={{ color: line.startsWith(';') ? 'var(--t3)' : 'var(--t2)' }}>
              {line || '\u00a0'}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
