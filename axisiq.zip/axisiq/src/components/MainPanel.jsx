import { useMachineStore } from '../store'
import RunTab from './RunTab'
import VisualizeTab from './VisualizeTab'
import ConsoleTab from './ConsoleTab'
import SetupTab from './SetupTab'
import AIPanel from './AIPanel'
import MaterialLibrary from './MaterialLibrary'
import RasterTab from './RasterTab'
import LaserPresetsTab from './LaserPresetsTab'
import LaserRunTab from './LaserRunTab'
import CameraTab from './CameraTab'
import './MainPanel.css'

const ROUTER_TABS = [
  { id: 'run',       label: 'Run' },
  { id: 'visualize', label: 'Visualize' },
  { id: 'camera',    label: '◉ Camera' },
  { id: 'console',   label: 'Console' },
  { id: 'setup',     label: 'Setup' },
  { id: 'ai',        label: '✦ AI Assist' },
]

const LASER_TABS = [
  { id: 'run',       label: 'Run' },
  { id: 'visualize', label: 'Visualize' },
  { id: 'camera',    label: '◉ Camera' },
  { id: 'materials', label: 'Materials' },
  { id: 'raster',    label: 'Raster' },
  { id: 'presets',   label: 'Presets' },
  { id: 'console',   label: 'Console' },
  { id: 'ai',        label: '✦ AI' },
]

export default function MainPanel() {
  const { activeTab, setActiveTab, machineType } = useMachineStore()
  const TABS = machineType === 'co2' ? LASER_TABS : ROUTER_TABS

  return (
    <div className="main-panel">
      <div className="tab-bar">
        {TABS.map(t => (
          <button
            key={t.id}
            className={`tab-btn ${activeTab === t.id ? 'tab-active' : ''}`}
            onClick={() => setActiveTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="tab-content">
        {/* Router tabs */}
        {machineType === 'router' && activeTab === 'run'       && <RunTab />}
        {machineType === 'router' && activeTab === 'setup'     && <SetupTab />}

        {/* Laser tabs */}
        {machineType === 'co2' && activeTab === 'run'       && <LaserRunTab />}
        {machineType === 'co2' && activeTab === 'materials' && <MaterialLibrary />}
        {machineType === 'co2' && activeTab === 'raster'    && <RasterTab />}
        {machineType === 'co2' && activeTab === 'presets'   && <LaserPresetsTab />}

        {/* Shared tabs */}
        {activeTab === 'camera'    && <CameraTab />}
        {activeTab === 'visualize' && <VisualizeTab />}
        {activeTab === 'console'   && <ConsoleTab />}
        {activeTab === 'ai'        && <AIPanel />}
      </div>
    </div>
  )
}
