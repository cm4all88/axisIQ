import { useState, useEffect, useRef } from 'react'
import { useMachineStore } from '../store'
import FramePanel from './FramePanel'
import './LaserRunTab.css'

const api = window.axisiq

const PREFLIGHT_LASER = [
  { id:'material',   text:'Correct material loaded and positioned' },
  { id:'focus',      text:'Focus height set for this material thickness' },
  { id:'origin',     text:'XY origin set and traced (origin trace run)' },
  { id:'air',        text:'Air assist on or off per material (leather = off)' },
  { id:'exhaust',    text:'Exhaust fan / ventilation running' },
  { id:'lid',        text:'Lid closed and interlock engaged' },
  { id:'eyewear',    text:'Laser safety eyewear on' },
  { id:'fire',       text:'Fire watch set, fire extinguisher accessible' },
]

function PreflightModal({ onConfirm, onClose }) {
  const [checked, setChecked] = useState({})
  const allDone = PREFLIGHT_LASER.every(i => checked[i.id])
  const count = Object.values(checked).filter(Boolean).length

  function toggle(id) {
    setChecked(c => {
      const n = Object.assign({}, c)
      n[id] = !c[id]
      return n
    })
  }

  return (
    <div className="modal-overlay">
      <div className="modal-box">
        <div className="modal-header">
          <span className="modal-title">Pre-Flight — Laser</span>
          <button onClick={onClose} className="modal-close">×</button>
        </div>
        <div className="modal-body">
          <p className="modal-desc">Laser safety check before every run. All items required.</p>
          {PREFLIGHT_LASER.map(item => {
            const on = checked[item.id]
            return (
              <button key={item.id} onClick={() => toggle(item.id)} className={`pf-item ${on ? 'pf-done' : ''}`}>
                <div className={`pf-check ${on ? 'pf-check-on' : ''}`}>{on ? '✓' : ''}</div>
                <span className="pf-text">{item.text}</span>
              </button>
            )
          })}
        </div>
        <div className="modal-footer">
          <button className="btn" onClick={onClose}>Cancel</button>
          <span className="pf-count">{count} / {PREFLIGHT_LASER.length}</span>
          <button className="btn btn-amber" disabled={!allDone} onClick={onConfirm}>▶ Start Job</button>
        </div>
      </div>
    </div>
  )
}

export default function LaserRunTab() {
  const {
    connected, machineState,
    laserPower, laserSpeed, laserPasses,
    activeMaterial,
    gcodeLines, fileName, currentLine, jobProgress,
    jobRunning, jobPaused, jobDone,
    loadFile, setJobRunning, setJobPaused, setJobResumed, setJobStopped, setJobDone,
    updateProgress, addLog,
  } = useMachineStore()

  const [framePassed, setFramePassed] = useState(false)
  const [feedOvr, setFeedOvr] = useState(100)
  const [powerOvr, setPowerOvr] = useState(100)

  async function openFile() {
    const result = await api?.openFile()
    if (!result || result.canceled) return
    loadFile({ fileName: result.fileName, lines: result.lines })
    setFramePassed(false)
    addLog({ type: 'info', text: `Loaded: ${result.fileName} (${result.lines.length} lines)`, time: Date.now() })
  }

  async function startJob() {
    if (!connected || !gcodeLines.length) return
    setJobRunning()
    await api?.startStream(gcodeLines)
  }

  async function pauseJob() {
    setJobPaused()
    await api?.pauseStream()
  }

  async function resumeJob() {
    setJobResumed()
    await api?.resumeStream()
  }

  async function stopJob() {
    setJobStopped()
    await api?.stopStream()
    await api?.send('M5')  // laser off
  }

  const before = (gcodeLines || []).slice(Math.max(0, currentLine - 2), currentLine)
  const current = (gcodeLines || [])[currentLine] || ''
  const after = (gcodeLines || []).slice(currentLine + 1, currentLine + 3)

  return (
    <div className="laser-run-tab">
      {preflight && (
        <PreflightModal
          onClose={() => setPreflight(false)}
          onConfirm={() => { setPreflight(false); startJob() }}
        />
      )}

      {/* Material badge */}
      {activeMaterial && (
        <div className="active-material">
          <span className="am-label">Material</span>
          <span className="am-name">{activeMaterial.name} {activeMaterial.thickness}mm</span>
          <span className="am-settings mono">
            {laserPower}% · {laserSpeed}mm/s · {laserPasses}×
          </span>
        </div>
      )}

      {/* File */}
      <div className="lr-section">
        <div className="lr-section-head">
          <span className="label">G-code / File</span>
          {fileName && <span className="lr-filename mono">{fileName}</span>}
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <button className="btn" onClick={openFile} disabled={jobRunning}>Open File…</button>
          {gcodeLines && gcodeLines.length > 0 && (
            <span className="mono" style={{ fontSize:12, color:'var(--t2)' }}>
              {gcodeLines.length} lines
            </span>
          )}
        </div>
      </div>

      {/* Frame — required before starting */}
      <FramePanel onFramePassed={() => setFramePassed(true)} />

      {/* Live overrides (mid-job) */}
      {(jobRunning || jobPaused) && (
        <div className="lr-section lr-overrides">
          <span className="label">Live Overrides</span>
          {[['Feed / Speed', feedOvr, setFeedOvr, 'var(--blue)'], ['Power', powerOvr, setPowerOvr, 'var(--amber)']].map(([label, val, set, color]) => (
            <div key={label} className="override-row">
              <span className="or-label">{label}</span>
              <input
                type="range" min={10} max={200} value={val}
                onChange={e => set(Number(e.target.value))}
                style={{ flex:1, accentColor: color }}
              />
              <span className="or-val mono" style={{ color }}>{val}%</span>
            </div>
          ))}
        </div>
      )}

      {/* Progress */}
      {gcodeLines && gcodeLines.length > 0 && jobProgress > 0 && (
        <div className="lr-section">
          <div className="lr-section-head">
            <span className="label">Progress</span>
            <span className="label" style={{ color:'var(--t2)' }}>{jobProgress}%</span>
          </div>
          <div className="lr-progress-bar">
            <div className="lr-progress-fill" style={{ width: jobProgress + '%' }} />
          </div>
          <span className="mono" style={{ fontSize:12, color:'var(--t2)' }}>
            Line {currentLine} / {gcodeLines.length}
          </span>
        </div>
      )}

      {/* Controls */}
      <div className="lr-controls">
        {!jobRunning && (
          <button
            className="btn btn-amber btn-lg"
            disabled={!connected || !framePassed}
            onClick={() => setPreflight(true)}
            title={!framePassed ? 'Run frame check first' : ''}
          >
            ▶ Start Job
          </button>
        )}
        {jobRunning && !jobPaused && (
          <>
            <button className="btn btn-lg" onClick={pauseJob}>⏸ Pause</button>
            <button className="btn btn-red btn-lg" onClick={stopJob}>■ Stop</button>
          </>
        )}
        {jobRunning && jobPaused && (
          <>
            <button className="btn btn-amber btn-lg" onClick={resumeJob}>▶ Resume</button>
            <button className="btn btn-red btn-lg" onClick={stopJob}>■ Stop</button>
          </>
        )}
        {!traceOk && !jobRunning && gcodeLines && gcodeLines.length > 0 && (
          <span style={{ fontSize:11, color:'var(--t3)', marginLeft:8 }}>Run origin trace first</span>
        )}
      </div>

      {/* Current line */}
      {jobRunning && (
        <div className="lr-section">
          <span className="label" style={{ display:'block', marginBottom:8 }}>Current Line</span>
          <div className="lr-line-preview">
            {before.map((l, i) => <div key={i} className="lr-line-dim">{l}</div>)}
            <div className="lr-line-active">
              <span style={{ fontSize:10 }}>▶</span>
              {current}
            </div>
            {after.map((l, i) => <div key={i} className="lr-line-dim">{l}</div>)}
          </div>
        </div>
      )}

      {jobDone && (
        <div className="lr-done">
          ✓ Job complete
        </div>
      )}
    </div>
  )
}
