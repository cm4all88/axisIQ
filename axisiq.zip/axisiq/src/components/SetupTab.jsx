import { useState } from 'react'
import { useMachineStore } from '../store'
import './SetupTab.css'

const api = window.axisiq

export default function SetupTab() {
  const { profile, setProfile, units, setUnits, connected } = useMachineStore()
  const [local, setLocal] = useState({ ...profile })
  const [saved, setSaved] = useState(false)

  function update(key, val) {
    setLocal(p => ({ ...p, [key]: val }))
    setSaved(false)
  }

  function saveProfile() {
    setProfile(local)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  async function sendSettings() {
    if (!connected) return
    await api?.send('$$')
  }

  async function unlock() {
    await api?.send('$X')
  }

  async function reset() {
    await api?.realtime(0x18)
  }

  async function checkMode() {
    await api?.send('$C')
  }

  return (
    <div className="setup-tab">
      <div className="setup-col">

        {/* Machine profile */}
        <div className="setup-section panel">
          <div className="setup-section-title">Machine Profile</div>

          <div className="setup-grid">
            <div className="setup-field">
              <label className="field-label">Name</label>
              <input value={local.name} onChange={e => update('name', e.target.value)} />
            </div>
            <div className="setup-field">
              <label className="field-label">Units</label>
              <select value={units} onChange={e => setUnits(e.target.value)}>
                <option value="mm">mm</option>
                <option value="inch">inch</option>
              </select>
            </div>
            <div className="setup-field">
              <label className="field-label">Width (X)</label>
              <input type="number" value={local.width} onChange={e => update('width', +e.target.value)} />
            </div>
            <div className="setup-field">
              <label className="field-label">Depth (Y)</label>
              <input type="number" value={local.depth} onChange={e => update('depth', +e.target.value)} />
            </div>
            <div className="setup-field">
              <label className="field-label">Height (Z)</label>
              <input type="number" value={local.height} onChange={e => update('height', +e.target.value)} />
            </div>
            <div className="setup-field">
              <label className="field-label">Max Feed</label>
              <input type="number" value={local.maxFeed} onChange={e => update('maxFeed', +e.target.value)} />
            </div>
          </div>

          <button className={`btn ${saved ? 'btn-amber' : ''}`} onClick={saveProfile}>
            {saved ? '✓ Saved' : 'Save Profile'}
          </button>
        </div>

        {/* Work offsets */}
        <div className="setup-section panel">
          <div className="setup-section-title">Work Offsets</div>

          <div className="wcs-grid">
            {['G54','G55','G56','G57','G58','G59'].map(wcs => (
              <button
                key={wcs}
                className="btn wcs-btn"
                onClick={() => api?.send(wcs)}
                disabled={!connected}
              >
                {wcs}
              </button>
            ))}
          </div>

          <div className="setup-hint">Select active work coordinate system</div>
        </div>

        {/* Machine commands */}
        <div className="setup-section panel">
          <div className="setup-section-title">Machine Commands</div>

          <div className="cmd-grid">
            <button className="btn" onClick={sendSettings} disabled={!connected}>
              View Settings ($$)
            </button>
            <button className="btn" onClick={unlock} disabled={!connected}>
              Unlock ($X)
            </button>
            <button className="btn" onClick={reset} disabled={!connected}>
              Soft Reset
            </button>
            <button className="btn" onClick={checkMode} disabled={!connected}>
              Check Mode ($C)
            </button>
            <button className="btn" onClick={() => api?.send('$H')} disabled={!connected}>
              Run Homing ($H)
            </button>
            <button className="btn" onClick={() => api?.send('G28')} disabled={!connected}>
              Go to Predefined (G28)
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
