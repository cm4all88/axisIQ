import { useState, useEffect, useRef } from 'react'
import { useMachineStore } from '../store'
import './LaserSidebar.css'

const api = window.axisiq

export default function LaserSidebar() {
  const {
    connected,
    laserPower, setLaserPower,
    laserSpeed, setLaserSpeed,
    laserPasses, setLaserPasses,
    laserFocus, setLaserFocus,
    laserMode, setLaserMode,
    airAssist, setAirAssist,
    fireWatchMins, setFireWatch,
    addLog,
  } = useMachineStore()

  const [jogStep, setJogStep] = useState(5)
  const [jogFeed, setJogFeed] = useState(3000)
  const [fireTimer, setFireTimer] = useState(null)
  const [fireAlert, setFireAlert] = useState(false)
  const timerRef = useRef(null)

  // Fire watch timer
  useEffect(() => {
    return () => { if (timerRef.current) clearInterval(timerRef.current) }
  }, [])

  function startFireWatch() {
    if (timerRef.current) clearInterval(timerRef.current)
    const secs = fireWatchMins * 60
    let remaining = secs
    setFireTimer(remaining)
    timerRef.current = setInterval(() => {
      remaining -= 1
      setFireTimer(remaining)
      if (remaining <= 0) {
        clearInterval(timerRef.current)
        setFireAlert(true)
        setFireTimer(null)
      }
    }, 1000)
  }

  function resetFireWatch() {
    setFireAlert(false)
    startFireWatch()
  }

  function stopFireWatch() {
    if (timerRef.current) clearInterval(timerRef.current)
    setFireTimer(null)
    setFireAlert(false)
  }

  function fmtTimer(s) {
    const m = Math.floor(s / 60)
    const sec = s % 60
    return `${m}:${String(sec).padStart(2, '0')}`
  }

  async function jog(axis, dir) {
    if (!connected) return
    const dist = dir * jogStep
    const cmd = `$J=G21G91${axis}${dist.toFixed(3)}F${jogFeed}`
    await api?.send(cmd)
  }

  async function setFocusHeight() {
    if (!connected) return
    await api?.send(`G0 Z${laserFocus.toFixed(3)}`)
    addLog({ type: 'info', text: `Focus set: Z${laserFocus}mm`, time: Date.now() })
  }

  async function testFire() {
    if (!connected) return
    const s = Math.round(laserPower / 100 * 1000)
    await api?.send(`M3 S${s}`)
    setTimeout(() => api?.send('M5'), 200)
  }

  async function toggleAir() {
    const next = !airAssist
    setAirAssist(next)
    await api?.send(next ? 'M8' : 'M9')
    addLog({ type: 'info', text: `Air assist ${next ? 'ON' : 'OFF'}`, time: Date.now() })
  }

  return (
    <aside className="laser-sidebar">

      {/* Fire watch alert */}
      {fireAlert && (
        <div className="fire-alert">
          <span className="fire-alert-icon">🔥</span>
          <div className="fire-alert-text">
            <strong>Fire Watch</strong>
            <span>Check machine now</span>
          </div>
          <button className="fire-alert-ok" onClick={resetFireWatch}>OK</button>
        </div>
      )}

      {/* Air assist — top, prominent for laser */}
      <div className="air-panel">
        <button
          className={`air-btn ${airAssist ? 'air-on' : ''}`}
          onClick={toggleAir}
          disabled={!connected}
        >
          <span className="air-icon">💨</span>
          <span className="air-label">Air Assist</span>
          <span className={`air-state ${airAssist ? 'on' : 'off'}`}>
            {airAssist ? 'ON' : 'off'}
          </span>
        </button>
      </div>

      {/* Power & speed */}
      <div className="laser-panel panel">
        <div className="panel-header">
          <span className="label">Laser Controls</span>
          <div className="mode-toggle">
            <button
              className={`mode-btn ${laserMode === 'dynamic' ? 'active' : ''}`}
              onClick={() => setLaserMode('dynamic')}
              title="M4 — power off when machine stops (safer)"
            >
              M4
            </button>
            <button
              className={`mode-btn ${laserMode === 'constant' ? 'active' : ''}`}
              onClick={() => setLaserMode('constant')}
              title="M3 — constant power"
            >
              M3
            </button>
          </div>
        </div>

        {/* Power */}
        <div className="laser-control">
          <div className="lc-header">
            <span className="lc-label">Power</span>
            <span className="lc-value">{laserPower}%</span>
          </div>
          <input
            type="range" min={0} max={100} value={laserPower}
            onChange={e => setLaserPower(Number(e.target.value))}
            className="laser-slider power-slider"
          />
          <div className="lc-presets">
            {[10, 25, 50, 75, 100].map(v => (
              <button
                key={v}
                className={`lc-preset ${laserPower === v ? 'active' : ''}`}
                onClick={() => setLaserPower(v)}
              >
                {v}%
              </button>
            ))}
          </div>
        </div>

        {/* Speed */}
        <div className="laser-control">
          <div className="lc-header">
            <span className="lc-label">Speed</span>
            <span className="lc-value mono">{laserSpeed} <span className="lc-unit">mm/s</span></span>
          </div>
          <input
            type="range" min={1} max={500} value={laserSpeed}
            onChange={e => setLaserSpeed(Number(e.target.value))}
            className="laser-slider speed-slider"
          />
          <div className="lc-presets">
            {[10, 50, 100, 200, 400].map(v => (
              <button
                key={v}
                className={`lc-preset ${laserSpeed === v ? 'active' : ''}`}
                onClick={() => setLaserSpeed(v)}
              >
                {v}
              </button>
            ))}
          </div>
        </div>

        {/* Passes */}
        <div className="passes-row">
          <span className="lc-label">Passes</span>
          <div className="passes-ctrl">
            <button
              className="pass-btn"
              onClick={() => setLaserPasses(Math.max(1, laserPasses - 1))}
            >
              −
            </button>
            <span className="pass-val mono">{laserPasses}</span>
            <button
              className="pass-btn"
              onClick={() => setLaserPasses(Math.min(10, laserPasses + 1))}
            >
              +
            </button>
          </div>
        </div>

        {/* Test fire */}
        <button
          className="btn btn-sm test-fire-btn"
          onClick={testFire}
          disabled={!connected}
        >
          ⚡ Test Fire (200ms)
        </button>
      </div>

      {/* Focus height */}
      <div className="panel focus-panel">
        <div className="panel-header">
          <span className="label">Focus Height</span>
          <span className="mono" style={{ fontSize: 11 }}>{laserFocus.toFixed(1)} mm</span>
        </div>
        <div className="focus-row">
          <input
            type="number"
            value={laserFocus}
            step={0.1}
            min={0}
            max={200}
            onChange={e => setLaserFocus(Number(e.target.value))}
            className="focus-input mono"
          />
          <span className="focus-unit">mm</span>
          <button
            className="btn btn-amber btn-sm"
            onClick={setFocusHeight}
            disabled={!connected}
          >
            Set Z
          </button>
        </div>
        <p className="focus-hint">Set once per material thickness. Use the physical focus tool or measure from nozzle to surface.</p>
      </div>

      {/* XY Jog */}
      <div className="panel jog-panel">
        <div className="panel-header">
          <span className="label">Jog</span>
          <span className="label" style={{ fontSize: 9, color: 'var(--t3)' }}>Arrow keys</span>
        </div>

        <div className="jog-grid">
          {['↖','↑','↗','←',null,'→','↙','↓','↘'].map((d, i) => {
            if (!d) return (
              <div key={i} className="jog-center-cell">XY</div>
            )
            const handlers = {
              '↖': () => { jog('X',-1); jog('Y',1) },
              '↑':  () => jog('Y', 1),
              '↗': () => { jog('X',1); jog('Y',1) },
              '←':  () => jog('X', -1),
              '→':  () => jog('X', 1),
              '↙': () => { jog('X',-1); jog('Y',-1) },
              '↓':  () => jog('Y', -1),
              '↘': () => { jog('X',1); jog('Y',-1) },
            }
            return (
              <button
                key={i}
                className="jog-btn"
                disabled={!connected}
                onClick={handlers[d]}
              >
                {d}
              </button>
            )
          })}
        </div>

        <div className="jog-steps">
          <span className="label">Step (mm)</span>
          <div className="step-row">
            {[0.1, 1, 5, 10, 50].map(s => (
              <button
                key={s}
                className={`step-btn ${jogStep === s ? 'active' : ''}`}
                onClick={() => setJogStep(s)}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Fire watch */}
      <div className="panel fire-watch-panel">
        <div className="panel-header">
          <span className="label">Fire Watch</span>
          {fireTimer !== null && (
            <span
              className={`fire-timer mono ${fireTimer <= 60 ? 'urgent' : ''}`}
            >
              {fmtTimer(fireTimer)}
            </span>
          )}
        </div>
        <div className="fw-row">
          <select
            value={fireWatchMins}
            onChange={e => setFireWatch(Number(e.target.value))}
            className="fw-select"
          >
            {[3, 5, 10, 15, 20, 30].map(m => (
              <option key={m} value={m}>{m} min</option>
            ))}
          </select>
          {fireTimer === null
            ? <button className="btn btn-sm fw-btn" onClick={startFireWatch}>Start</button>
            : <button className="btn btn-sm fw-btn" onClick={stopFireWatch}>Stop</button>
          }
        </div>
        <p className="focus-hint">Alerts you to visually check the machine at the set interval.</p>
      </div>
    </aside>
  )
}
