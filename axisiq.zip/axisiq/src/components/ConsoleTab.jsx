import { useEffect, useRef, useState } from 'react'
import { useMachineStore } from '../store'
import './ConsoleTab.css'

const api = window.axisiq

const QUICK_CMDS = [
  { label: '$$', cmd: '$$', title: 'View settings' },
  { label: '$#', cmd: '$#', title: 'View gcode parameters' },
  { label: '$G', cmd: '$G', title: 'View parser state' },
  { label: '$I', cmd: '$I', title: 'View build info' },
  { label: '$X', cmd: '$X', title: 'Kill alarm lock' },
  { label: '?',  cmd: '?',  title: 'Status report' },
  { label: 'M3 S1000', cmd: 'M3 S1000', title: 'Spindle on 1000rpm' },
  { label: 'M5', cmd: 'M5', title: 'Spindle off' },
]

export default function ConsoleTab() {
  const { consoleLog, clearLog, connected } = useMachineStore()
  const [input, setInput] = useState('')
  const [history, setHistory] = useState([])
  const [histIdx, setHistIdx] = useState(-1)
  const [autoScroll, setAutoScroll] = useState(true)
  const logRef = useRef(null)

  useEffect(() => {
    if (autoScroll && logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight
    }
  }, [consoleLog, autoScroll])

  async function sendCmd(cmd) {
    if (!connected || !cmd.trim()) return
    await api?.send(cmd.trim())
    setHistory(h => [cmd, ...h.slice(0, 49)])
    setInput('')
    setHistIdx(-1)
  }

  function onKeyDown(e) {
    if (e.key === 'Enter') {
      sendCmd(input)
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      const next = Math.min(histIdx + 1, history.length - 1)
      setHistIdx(next)
      setInput(history[next] || '')
    } else if (e.key === 'ArrowDown') {
      e.preventDefault()
      const next = Math.max(histIdx - 1, -1)
      setHistIdx(next)
      setInput(next === -1 ? '' : history[next] || '')
    }
  }

  function onScroll(e) {
    const el = e.target
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 20
    setAutoScroll(atBottom)
  }

  function logColor(type) {
    if (type === 'sent')  return 'var(--amber)'
    if (type === 'recv')  return 'var(--text)'
    if (type === 'error') return 'var(--red)'
    return 'var(--text-3)'
  }

  function logPrefix(type) {
    if (type === 'sent')  return '→'
    if (type === 'recv')  return '←'
    if (type === 'error') return '!'
    return '·'
  }

  function fmtTime(ts) {
    return new Date(ts).toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })
  }

  return (
    <div className="console-tab">
      {/* Quick commands */}
      <div className="console-quick">
        {QUICK_CMDS.map(q => (
          <button
            key={q.cmd}
            className="btn btn-sm console-quick-btn"
            onClick={() => sendCmd(q.cmd)}
            disabled={!connected}
            title={q.title}
          >
            {q.label}
          </button>
        ))}
        <button className="btn btn-sm btn-ghost" onClick={clearLog} style={{ marginLeft: 'auto' }}>
          Clear
        </button>
      </div>

      {/* Log */}
      <div className="console-log" ref={logRef} onScroll={onScroll}>
        {consoleLog.length === 0 && (
          <div className="console-empty">Connect to a machine to see output</div>
        )}
        {consoleLog.map((entry, i) => (
          <div key={i} className="console-row">
            <span className="console-time">{fmtTime(entry.time)}</span>
            <span className="console-prefix" style={{ color: logColor(entry.type) }}>
              {logPrefix(entry.type)}
            </span>
            <span className="console-text" style={{ color: logColor(entry.type) }}>
              {entry.text}
            </span>
          </div>
        ))}
        {!autoScroll && (
          <button
            className="console-scroll-btn"
            onClick={() => { setAutoScroll(true); logRef.current.scrollTop = logRef.current.scrollHeight }}
          >
            ↓ Jump to latest
          </button>
        )}
      </div>

      {/* Input */}
      <div className="console-input-row">
        <span className="console-prompt">&gt;</span>
        <input
          className="console-input"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder={connected ? 'Enter G-code or $ command… (↑↓ history)' : 'Not connected'}
          disabled={!connected}
          autoComplete="off"
          spellCheck={false}
        />
        <button
          className="btn btn-sm btn-amber"
          onClick={() => sendCmd(input)}
          disabled={!connected || !input.trim()}
        >
          Send
        </button>
      </div>
    </div>
  )
}
