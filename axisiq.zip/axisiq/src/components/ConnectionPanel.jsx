import { useEffect, useState } from 'react'
import { useMachineStore } from '../store'
import './ConnectionPanel.css'

const api = window.axisiq

const BAUD_RATES = [115200, 57600, 38400, 19200, 9600]

export default function ConnectionPanel() {
  const {
    ports, setPortList,
    selectedPort, setSelectedPort,
    baudRate, setBaudRate,
    connected, setConnected, setDisconnected,
    addLog,
  } = useMachineStore()

  const [loading, setLoading] = useState(false)

  useEffect(() => { refreshPorts() }, [])

  async function refreshPorts() {
    if (!api) return
    const list = await api.listPorts()
    setPortList(list)
    if (list.length && !selectedPort) setSelectedPort(list[0].path)
  }

  async function handleConnect() {
    if (!selectedPort || !api) return
    setLoading(true)
    const result = await api.connect({ path: selectedPort, baudRate })
    setLoading(false)
    if (result.success) {
      setConnected(true)
      addLog({ type: 'info', text: `Connected: ${selectedPort}`, time: Date.now() })
    } else {
      addLog({ type: 'error', text: result.error, time: Date.now() })
    }
  }

  async function handleDisconnect() {
    await api?.disconnect()
    setDisconnected()
  }

  return (
    <div className="panel conn-panel">
      <div className="panel-header">
        <span className="label">Connection</span>
        <button className="btn btn-ghost btn-sm" onClick={refreshPorts} title="Refresh ports">↻</button>
      </div>

      <div className="conn-fields">
        <div className="field-row">
          <label className="field-label">Port</label>
          <select
            value={selectedPort}
            onChange={e => setSelectedPort(e.target.value)}
            disabled={connected}
            className="field-select"
          >
            {ports.length === 0 && <option value="">No ports found</option>}
            {ports.map(p => (
              <option key={p.path} value={p.path}>
                {p.path} {p.manufacturer ? `— ${p.manufacturer}` : ''}
              </option>
            ))}
          </select>
        </div>

        <div className="field-row">
          <label className="field-label">Baud</label>
          <select
            value={baudRate}
            onChange={e => setBaudRate(Number(e.target.value))}
            disabled={connected}
            className="field-select field-select-sm"
          >
            {BAUD_RATES.map(b => <option key={b} value={b}>{b}</option>)}
          </select>
        </div>
      </div>

      <div className="conn-actions">
        {!connected ? (
          <button
            className="btn btn-amber conn-btn"
            onClick={handleConnect}
            disabled={!selectedPort || loading}
          >
            {loading ? 'Connecting…' : 'Connect'}
          </button>
        ) : (
          <button className="btn btn-red conn-btn" onClick={handleDisconnect}>
            Disconnect
          </button>
        )}
      </div>
    </div>
  )
}
