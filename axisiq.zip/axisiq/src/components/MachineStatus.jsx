import { useMachineStore } from '../store'
import './MachineStatus.css'

const api = window.axisiq

export default function MachineStatus() {
  const { position, feedRate, spindleSpeed, overrides, machineState, units, connected } = useMachineStore()

  const fmt = (v) => v.toFixed(3).padStart(8, ' ')

  async function zeroAxis(axis) {
    const cmd = axis === 'all' ? 'G10 L20 P1 X0 Y0 Z0' : `G10 L20 P1 ${axis.toUpperCase()}0`
    await api?.send(cmd)
  }

  async function goHome() {
    await api?.send('$H')
  }

  return (
    <div className="panel status-panel">
      <div className="panel-header">
        <span className="label">Position</span>
        <span className="label" style={{ color: 'var(--text-2)' }}>{units}</span>
      </div>

      <div className="axis-readout">
        {['x', 'y', 'z'].map(axis => (
          <div key={axis} className="axis-row">
            <span className="axis-name">{axis.toUpperCase()}</span>
            <span className="axis-value mono">{fmt(position[axis])}</span>
            <button
              className="btn btn-ghost btn-sm axis-zero"
              onClick={() => zeroAxis(axis)}
              disabled={!connected}
              title={`Zero ${axis.toUpperCase()}`}
            >
              Z
            </button>
          </div>
        ))}
      </div>

      <div className="status-actions">
        <button className="btn btn-sm" onClick={() => zeroAxis('all')} disabled={!connected}>
          Zero All
        </button>
        <button className="btn btn-sm" onClick={goHome} disabled={!connected}>
          Home
        </button>
      </div>

      <div className="divider" />

      <div className="status-metrics">
        <div className="metric">
          <span className="metric-label">Feed</span>
          <span className="metric-value mono">{feedRate} <span className="metric-unit">{units}/min</span></span>
        </div>
        <div className="metric">
          <span className="metric-label">Spindle</span>
          <span className="metric-value mono">{spindleSpeed} <span className="metric-unit">rpm</span></span>
        </div>
      </div>

      {overrides && (
        <div className="override-row">
          <span className="override-item">F {overrides.feed}%</span>
          <span className="override-item">R {overrides.rapid}%</span>
          <span className="override-item">S {overrides.spindle}%</span>
        </div>
      )}
    </div>
  )
}
