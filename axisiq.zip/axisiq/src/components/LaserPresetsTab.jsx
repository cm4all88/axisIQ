import { useState } from 'react'
import { useMachineStore } from '../store'
import './LaserPresetsTab.css'

const api = window.axisiq

// ── Test grid G-code generator ────────────────────────────────────────────────

function generateTestGrid({ powerMin, powerMax, speedMin, speedMax, cols, rows, cellSize, gap }) {
  const lines = []
  lines.push('; AxisIQ — Power/Speed Test Grid')
  lines.push(`; Power ${powerMin}–${powerMax}%  Speed ${speedMin}–${speedMax}mm/s`)
  lines.push(`; Grid ${cols}×${rows}  Cell ${cellSize}mm  Gap ${gap}mm`)
  lines.push('G21 G90')
  lines.push('$32=1')
  lines.push('M4 S0')
  lines.push('G0 Z5.000')
  lines.push('')

  const step = cellSize + gap

  for (let row = 0; row < rows; row++) {
    const speed = speedMin + (speedMax - speedMin) * (row / Math.max(rows - 1, 1))
    const feedMmm = Math.round(speed * 60)

    for (let col = 0; col < cols; col++) {
      const power = powerMin + (powerMax - powerMin) * (col / Math.max(cols - 1, 1))
      const S = Math.round(power / 100 * 1000)

      const x1 = (col * step).toFixed(3)
      const y1 = (row * step).toFixed(3)
      const x2 = (col * step + cellSize).toFixed(3)
      const y2 = (row * step + cellSize).toFixed(3)

      lines.push(`; Cell [${col+1},${row+1}]  P=${power.toFixed(0)}%  S=${speed.toFixed(0)}mm/s`)
      lines.push(`G0 X${x1} Y${y1}`)
      lines.push(`G1 Z0.000 S${S} F${feedMmm}`)
      lines.push(`G1 X${x2}`)
      lines.push(`G1 Y${y2}`)
      lines.push(`G1 X${x1}`)
      lines.push(`G1 Y${y1}`)
      lines.push(`M4 S0`)
      lines.push(`G0 Z1.000`)
    }
  }

  lines.push('')
  lines.push('M5')
  lines.push('G0 X0.000 Y0.000')
  lines.push('M30')
  return lines.join('\n')
}

// ── Hatch fill generator ──────────────────────────────────────────────────────

function generateHatch({ width, height, spacing, angle, power, speed }) {
  const lines = []
  lines.push('; AxisIQ — Hatch Fill')
  lines.push(`; ${width}×${height}mm  Spacing ${spacing}mm  Angle ${angle}deg`)
  lines.push('G21 G90')
  lines.push('$32=1')
  lines.push(`M4 S0`)

  const rad = angle * Math.PI / 180
  const S = Math.round(power / 100 * 1000)
  const feedMmm = Math.round(speed * 60)

  if (Math.abs(angle) < 1) {
    // Horizontal lines
    lines.push(`G0 X0.000 Y0.000`)
    let y = 0, row = 0
    while (y <= height) {
      lines.push(`G0 X${row%2===0?'0.000':width.toFixed(3)} Y${y.toFixed(3)}`)
      lines.push(`G1 X${row%2===0?width.toFixed(3):'0.000'} S${S} F${feedMmm}`)
      lines.push(`M4 S0`)
      y += spacing
      row++
    }
  } else {
    // Angled lines — project across bounding box
    const diag = Math.sqrt(width * width + height * height)
    const count = Math.ceil(diag / spacing)
    for (let i = -count; i <= count; i++) {
      const offset = i * spacing
      const x1 = offset * Math.cos(rad + Math.PI/2)
      const y1 = offset * Math.sin(rad + Math.PI/2)
      const x2 = x1 + diag * Math.cos(rad)
      const y2 = y1 + diag * Math.sin(rad)
      // Clip to bounding box (simplified)
      lines.push(`; Line ${i}`)
      lines.push(`G0 X${x1.toFixed(3)} Y${y1.toFixed(3)}`)
      lines.push(`G1 X${x2.toFixed(3)} Y${y2.toFixed(3)} S${S} F${feedMmm}`)
      lines.push(`M4 S0`)
    }
  }

  lines.push('')
  lines.push('M5')
  lines.push('G0 X0.000 Y0.000')
  lines.push('M30')
  return lines.join('\n')
}

// ── Component ─────────────────────────────────────────────────────────────────

const PRESETS = [
  { id:'cut',      icon:'✂',  label:'Cut Outline',     color:'var(--red)' },
  { id:'engrave',  icon:'◈',  label:'Engrave Fill',    color:'var(--amber)' },
  { id:'score',    icon:'—',  label:'Score / Mark',    color:'var(--blue)' },
  { id:'testgrid', icon:'⊞',  label:'Test Grid',       color:'var(--purple)', badge:'✦' },
  { id:'photo',    icon:'◫',  label:'Photo Engrave',   color:'var(--green)' },
  { id:'hatch',    icon:'▤',  label:'Hatch Fill',      color:'var(--amber)' },
]

export default function LaserPresetsTab() {
  const { connected, laserPower, laserSpeed, laserPasses, addLog } = useMachineStore()

  const [active, setActive] = useState('testgrid')
  const [showCode, setShowCode] = useState(false)

  // Cut params
  const [cutW, setCutW] = useState(100)
  const [cutH, setCutH] = useState(80)
  const [cutPow, setCutPow] = useState(laserPower)
  const [cutSpd, setCutSpd] = useState(laserSpeed)
  const [cutPass, setCutPass] = useState(laserPasses)
  const [cornerR, setCornerR] = useState(0)

  // Engrave params
  const [engW, setEngW] = useState(100)
  const [engH, setEngH] = useState(80)
  const [engPow, setEngPow] = useState(Math.round(laserPower * 0.4))
  const [engSpd, setEngSpd] = useState(150)
  const [engDpi, setEngDpi] = useState(254)
  const [engInset, setEngInset] = useState(0)

  // Score params
  const [scorePow, setScorePow] = useState(15)
  const [scoreSpd, setScoreSpd] = useState(300)

  // Test grid params
  const [tgPowMin, setTgPowMin] = useState(20)
  const [tgPowMax, setTgPowMax] = useState(80)
  const [tgSpdMin, setTgSpdMin] = useState(50)
  const [tgSpdMax, setTgSpdMax] = useState(300)
  const [tgCols, setTgCols]     = useState(5)
  const [tgRows, setTgRows]     = useState(5)
  const [tgCell, setTgCell]     = useState(10)
  const [tgGap, setTgGap]       = useState(2)

  // Hatch params
  const [htW, setHtW]         = useState(80)
  const [htH, setHtH]         = useState(60)
  const [htSpacing, setHtSpacing] = useState(0.5)
  const [htAngle, setHtAngle] = useState(45)
  const [htPow, setHtPow]     = useState(laserPower)
  const [htSpd, setHtSpd]     = useState(laserSpeed)

  function getCode() {
    if (active === 'testgrid') {
      return generateTestGrid({ powerMin:tgPowMin, powerMax:tgPowMax, speedMin:tgSpdMin, speedMax:tgSpdMax, cols:tgCols, rows:tgRows, cellSize:tgCell, gap:tgGap })
    }
    if (active === 'hatch') {
      return generateHatch({ width:htW, height:htH, spacing:htSpacing, angle:htAngle, power:htPow, speed:htSpd })
    }
    if (active === 'cut') {
      const r = cornerR > 0 ? `\n; Corner radius: ${cornerR}mm` : ''
      const S = Math.round(cutPow / 100 * 1000)
      const F = Math.round(cutSpd * 60)
      const lines = [
        '; AxisIQ — Cut Outline', `; ${cutW}×${cutH}mm  ${cutPow}%  ${cutSpd}mm/s  ${cutPass} pass(es)${r}`,
        'G21 G90', '$32=1', 'M4 S0', 'G0 Z5.000', '',
      ]
      for (let p = 0; p < cutPass; p++) {
        lines.push(`; Pass ${p+1}`)
        lines.push(`G0 X0.000 Y0.000`)
        lines.push(`G1 Z0.000 S${S} F${F}`)
        lines.push(`G1 X${cutW}.000`)
        lines.push(`G1 Y${cutH}.000`)
        lines.push(`G1 X0.000`)
        lines.push(`G1 Y0.000`)
        lines.push(`M4 S0\nG0 Z2.000`)
      }
      lines.push('', 'M5', 'G0 X0 Y0', 'M30')
      return lines.join('\n')
    }
    return '; Select a preset to generate G-code'
  }

  function NF({ label, value, onChange, unit, min, max, step }) {
    return (
      <div className="lp-field">
        <label>{label}</label>
        <div className="lp-input-row">
          <input type="number" value={value} min={min} max={max} step={step||1}
            onChange={function(e){onChange(Number(e.target.value))}} />
          {unit && <span className="lp-unit">{unit}</span>}
        </div>
      </div>
    )
  }

  const tgTotalCells = tgCols * tgRows
  const tgWidth = tgCols * (tgCell + tgGap) - tgGap
  const tgHeight = tgRows * (tgCell + tgGap) - tgGap

  return (
    <div className="laser-presets-tab">

      {/* Preset picker */}
      <div className="lp-picker">
        {PRESETS.map(p => (
          <button
            key={p.id}
            className={`lp-btn ${active === p.id ? 'lp-active' : ''}`}
            onClick={() => { setActive(p.id); setShowCode(false) }}
            style={{ '--pc': p.color }}
          >
            {p.badge && <span className="lp-badge">{p.badge}</span>}
            <span className="lp-icon">{p.icon}</span>
            <span className="lp-label">{p.label}</span>
          </button>
        ))}
      </div>

      {/* Params panel */}
      <div className="lp-content">

        {active === 'testgrid' && (
          <div className="lp-form">
            <div className="lp-form-header">
              <h3>Power / Speed Test Grid</h3>
              <p>Cuts a grid of squares with varying power (columns) and speed (rows). Run on scrap material to find optimal settings for any material in one pass.</p>
            </div>

            <div className="lp-grid-preview">
              <div className="tg-preview-grid" style={{ '--cols': tgCols, '--rows': tgRows }}>
                {Array.from({ length: tgCols * tgRows }).map((_, i) => {
                  const col = i % tgCols, row = Math.floor(i / tgCols)
                  const power = tgPowMin + (tgPowMax - tgPowMin) * (col / Math.max(tgCols-1,1))
                  const opacity = 0.15 + 0.75 * (power / 100)
                  return (
                    <div key={i} className="tg-cell" style={{ opacity }}>
                      {i === 0 && <span className="tg-cell-label">{tgPowMin}%</span>}
                      {col === tgCols-1 && row === 0 && <span className="tg-cell-label">{tgPowMax}%</span>}
                    </div>
                  )
                })}
              </div>
              <div className="tg-axis-labels">
                <span>← Power {tgPowMin}% → {tgPowMax}%</span>
                <span>↕ Speed {tgSpdMin}–{tgSpdMax} mm/s</span>
              </div>
            </div>

            <div className="lp-fields">
              <NF label="Power min" value={tgPowMin} onChange={setTgPowMin} unit="%" min={1} max={tgPowMax-5} />
              <NF label="Power max" value={tgPowMax} onChange={setTgPowMax} unit="%" min={tgPowMin+5} max={100} />
              <NF label="Speed min" value={tgSpdMin} onChange={setTgSpdMin} unit="mm/s" min={1} max={tgSpdMax-10} />
              <NF label="Speed max" value={tgSpdMax} onChange={setTgSpdMax} unit="mm/s" min={tgSpdMin+10} max={500} />
              <NF label="Columns" value={tgCols} onChange={setTgCols} min={2} max={10} />
              <NF label="Rows" value={tgRows} onChange={setTgRows} min={2} max={10} />
              <NF label="Cell size" value={tgCell} onChange={setTgCell} unit="mm" min={5} max={30} />
              <NF label="Gap" value={tgGap} onChange={setTgGap} unit="mm" min={1} max={10} />
            </div>

            <div className="tg-stats">
              <div><span>Total cells</span><strong>{tgTotalCells}</strong></div>
              <div><span>Grid size</span><strong>{tgWidth}×{tgHeight}mm</strong></div>
              <div><span>Est. time</span><strong>~{Math.ceil(tgTotalCells * tgCell * 4 / tgSpdMin / 60)}min</strong></div>
            </div>
          </div>
        )}

        {active === 'cut' && (
          <div className="lp-form">
            <div className="lp-form-header">
              <h3>Cut Outline</h3>
              <p>Cuts a rectangle at the specified power and speed. Add a corner radius for rounded parts.</p>
            </div>
            <div className="lp-fields">
              <NF label="Width" value={cutW} onChange={setCutW} unit="mm" min={1} />
              <NF label="Height" value={cutH} onChange={setCutH} unit="mm" min={1} />
              <NF label="Power" value={cutPow} onChange={setCutPow} unit="%" min={1} max={100} />
              <NF label="Speed" value={cutSpd} onChange={setCutSpd} unit="mm/s" min={1} max={500} />
              <NF label="Passes" value={cutPass} onChange={setCutPass} min={1} max={10} />
              <NF label="Corner radius" value={cornerR} onChange={setCornerR} unit="mm" min={0} max={50} />
            </div>
          </div>
        )}

        {active === 'engrave' && (
          <div className="lp-form">
            <div className="lp-form-header">
              <h3>Engrave Fill</h3>
              <p>Raster-fills a rectangular area. Lower power and higher speed than cutting.</p>
            </div>
            <div className="lp-fields">
              <NF label="Width" value={engW} onChange={setEngW} unit="mm" min={1} />
              <NF label="Height" value={engH} onChange={setEngH} unit="mm" min={1} />
              <NF label="Power" value={engPow} onChange={setEngPow} unit="%" min={1} max={100} />
              <NF label="Speed" value={engSpd} onChange={setEngSpd} unit="mm/s" min={10} max={500} />
              <NF label="DPI" value={engDpi} onChange={setEngDpi} min={75} max={500} step={25} />
              <NF label="Inset" value={engInset} onChange={setEngInset} unit="mm" min={0} max={20} />
            </div>
          </div>
        )}

        {active === 'score' && (
          <div className="lp-form">
            <div className="lp-form-header">
              <h3>Score / Mark</h3>
              <p>Very low power pass for marking fold lines, alignment marks, or light surface scoring.</p>
            </div>
            <div className="lp-fields">
              <NF label="Power" value={scorePow} onChange={setScorePow} unit="%" min={1} max={50} />
              <NF label="Speed" value={scoreSpd} onChange={setScoreSpd} unit="mm/s" min={10} max={500} />
            </div>
            <div className="lp-note">
              ⚡ Score uses very low power — just enough to leave a visible line without cutting through. Ideal for fold lines in cardstock or alignment marks in wood.
            </div>
          </div>
        )}

        {active === 'photo' && (
          <div className="lp-form">
            <div className="lp-form-header">
              <h3>Photo Engrave</h3>
              <p>Optimized settings for photographic image engraving. Uses variable power (M4 dynamic mode) to reproduce grayscale tones.</p>
            </div>
            <div className="lp-note" style={{ marginBottom: 16 }}>
              ✦ Photo engraving uses the Raster tab with Floyd-Steinberg dithering and dynamic power mode. Switch to the Raster tab and load your image for full control.
            </div>
            <div className="lp-fields">
              <NF label="Min power" value={5} onChange={() => {}} unit="%" min={1} max={30} />
              <NF label="Max power" value={70} onChange={() => {}} unit="%" min={20} max={100} />
              <NF label="Speed" value={100} onChange={() => {}} unit="mm/s" min={50} max={300} />
              <NF label="DPI" value={254} onChange={() => {}} min={150} max={400} step={25} />
            </div>
          </div>
        )}

        {active === 'hatch' && (
          <div className="lp-form">
            <div className="lp-form-header">
              <h3>Hatch Fill</h3>
              <p>Fills an area with parallel engraving lines at any angle. Good for shading effects and area fills.</p>
            </div>
            <div className="lp-fields">
              <NF label="Width" value={htW} onChange={setHtW} unit="mm" min={1} />
              <NF label="Height" value={htH} onChange={setHtH} unit="mm" min={1} />
              <NF label="Line spacing" value={htSpacing} onChange={setHtSpacing} unit="mm" min={0.1} max={5} step={0.1} />
              <NF label="Angle" value={htAngle} onChange={setHtAngle} unit="deg" min={0} max={180} step={5} />
              <NF label="Power" value={htPow} onChange={setHtPow} unit="%" min={1} max={100} />
              <NF label="Speed" value={htSpd} onChange={setHtSpd} unit="mm/s" min={10} max={500} />
            </div>
            <div className="tg-stats">
              <div><span>Lines</span><strong>{Math.ceil(Math.sqrt(htW*htW+htH*htH) / htSpacing)}</strong></div>
              <div><span>Coverage</span><strong>{htW}×{htH}mm</strong></div>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="lp-actions">
          <button
            className="btn btn-ghost btn-sm"
            onClick={() => setShowCode(v => !v)}
          >
            {showCode ? 'Hide' : 'Preview'} G-code
          </button>
          <button
            className="btn btn-amber"
            disabled={!connected}
          >
            ▶ Generate &amp; Run
          </button>
        </div>

        {showCode && (
          <div className="lp-code">
            {getCode().split('\n').map((line, i) => (
              <div key={i} style={{ color: line.startsWith(';') ? 'var(--t3)' : 'var(--t2)' }}>
                {line || '\u00a0'}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
