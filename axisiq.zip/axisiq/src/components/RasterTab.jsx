import { useState, useRef, useEffect, useCallback } from 'react'
import { useMachineStore } from '../store'
import './RasterTab.css'

const DITHER_MODES = [
  { id: 'threshold',    label: 'Threshold',        desc: 'Pure black/white. Sharpest lines.' },
  { id: 'floyd',        label: 'Floyd-Steinberg',  desc: 'Best for photos. Diffuses error.' },
  { id: 'ordered',      label: 'Ordered (Bayer)',   desc: 'Dot pattern. Good for gradients.' },
  { id: 'lineart',      label: 'Line Art',          desc: 'High contrast. No dithering.' },
]

const DPI_OPTIONS = [75, 127, 150, 200, 254, 300, 500]

export default function RasterTab() {
  const { connected, laserPower, laserSpeed, addLog } = useMachineStore()

  const [image, setImage]     = useState(null)   // ImageData after processing
  const [fileName, setFileName] = useState('')
  const [dragging, setDragging] = useState(false)

  // Settings
  const [dpi, setDpi]             = useState(254)
  const [dither, setDither]       = useState('floyd')
  const [scanDir, setScanDir]     = useState('x')
  const [bidir, setBidir]         = useState(true)
  const [power, setPower]         = useState(laserPower)
  const [speed, setSpeed]         = useState(laserSpeed)
  const [powerCurve, setPowerCurve] = useState(50) // midpoint gamma
  const [invert, setInvert]       = useState(false)
  const [contrast, setContrast]   = useState(0)
  const [brightness, setBrightness] = useState(0)

  // Output stats
  const [stats, setStats]   = useState(null)
  const [gcodeReady, setGcodeReady] = useState(false)
  const [showCode, setShowCode]     = useState(false)
  const [previewCode, setPreviewCode] = useState('')

  const previewRef  = useRef(null)
  const processRef  = useRef(null)
  const fileInputRef = useRef(null)

  // Load and process image
  function loadImageFile(file) {
    if (!file || !file.type.startsWith('image/')) return
    setFileName(file.name)
    const reader = new FileReader()
    reader.onload = function(e) {
      const img = new Image()
      img.onload = function() {
        setImage(img)
        setGcodeReady(false)
      }
      img.src = e.target.result
    }
    reader.readAsDataURL(file)
  }

  // Process image onto preview canvas
  useEffect(() => {
    if (!image || !previewRef.current) return

    const canvas = previewRef.current
    const ctx = canvas.getContext('2d')

    // Scale to canvas
    const maxW = canvas.width, maxH = canvas.height
    const scale = Math.min(maxW / image.width, maxH / image.height, 1)
    const W = Math.round(image.width * scale)
    const H = Math.round(image.height * scale)
    canvas.width = maxW
    canvas.height = maxH

    ctx.fillStyle = '#17171a'
    ctx.fillRect(0, 0, maxW, maxH)

    // Draw original centered
    const ox = (maxW - W) / 2, oy = (maxH - H) / 2

    // Draw to offscreen, get pixel data, process
    const off = document.createElement('canvas')
    off.width = W; off.height = H
    const offCtx = off.getContext('2d')
    offCtx.drawImage(image, 0, 0, W, H)

    const imgData = offCtx.getImageData(0, 0, W, H)
    const data = imgData.data

    // Convert to grayscale with brightness/contrast
    for (let i = 0; i < data.length; i += 4) {
      let g = 0.299 * data[i] + 0.587 * data[i+1] + 0.114 * data[i+2]

      // Brightness
      g = Math.min(255, Math.max(0, g + brightness * 2.55))

      // Contrast
      const factor = (259 * (contrast + 255)) / (255 * (259 - contrast))
      g = Math.min(255, Math.max(0, factor * (g - 128) + 128))

      // Invert
      if (invert) g = 255 - g

      data[i] = data[i+1] = data[i+2] = g
    }

    // Apply dithering
    if (dither === 'threshold' || dither === 'lineart') {
      const threshold = dither === 'lineart' ? 200 : 128
      for (let i = 0; i < data.length; i += 4) {
        const v = data[i] < threshold ? 0 : 255
        data[i] = data[i+1] = data[i+2] = v
      }
    } else if (dither === 'floyd') {
      // Floyd-Steinberg
      for (let y = 0; y < H; y++) {
        for (let x = 0; x < W; x++) {
          const idx = (y * W + x) * 4
          const old = data[idx]
          const nv = old < 128 ? 0 : 255
          data[idx] = data[idx+1] = data[idx+2] = nv
          const err = old - nv
          const push = (ox2, oy2, factor) => {
            const nx = x + ox2, ny = y + oy2
            if (nx >= 0 && nx < W && ny >= 0 && ny < H) {
              const ni = (ny * W + nx) * 4
              data[ni] = Math.min(255, Math.max(0, data[ni] + err * factor))
              data[ni+1] = data[ni+2] = data[ni]
            }
          }
          push(1, 0, 7/16); push(-1, 1, 3/16); push(0, 1, 5/16); push(1, 1, 1/16)
        }
      }
    } else if (dither === 'ordered') {
      const bayer = [[0,8,2,10],[12,4,14,6],[3,11,1,9],[15,7,13,5]]
      for (let y = 0; y < H; y++) {
        for (let x = 0; x < W; x++) {
          const idx = (y * W + x) * 4
          const threshold = (bayer[y % 4][x % 4] / 16) * 255
          const v = data[idx] > threshold ? 255 : 0
          data[idx] = data[idx+1] = data[idx+2] = v
        }
      }
    }

    offCtx.putImageData(imgData, 0, 0)

    // Render preview with amber tint for laser effect
    ctx.fillStyle = '#17171a'
    ctx.fillRect(0, 0, maxW, maxH)
    ctx.globalCompositeOperation = 'source-over'
    ctx.drawImage(off, ox, oy, W, H)

    // Amber overlay on dark pixels (laser burns dark areas)
    const previewData = ctx.getImageData(ox, oy, W, H)
    for (let i = 0; i < previewData.data.length; i += 4) {
      if (previewData.data[i] < 128) {
        previewData.data[i] = 180
        previewData.data[i+1] = 90
        previewData.data[i+2] = 10
      }
    }
    ctx.putImageData(previewData, ox, oy)

    // Calculate stats
    const lines = Math.round(H / (25.4 / dpi))
    const lineLength = W / (25.4 / dpi)
    const totalDist = lines * lineLength + lines * 5  // approximate travel
    const estSecs = Math.round(totalDist / speed)

    setStats({
      lines,
      pixels: W * H,
      width: Math.round(image.width * (25.4 / dpi)),
      height: Math.round(image.height * (25.4 / dpi)),
      estimatedSecs: estSecs,
      resolution: `${W}×${H}px`,
    })
    setGcodeReady(true)
  }, [image, dither, dpi, invert, contrast, brightness])

  function generateGcode() {
    if (!image) return ''
    const lines = []
    lines.push('; AxisIQ Raster Engrave')
    lines.push('; File: ' + fileName)
    lines.push('; DPI: ' + dpi + '  Speed: ' + speed + 'mm/s  Power: ' + power + '%')
    lines.push('; Dither: ' + dither + '  Direction: ' + scanDir)
    lines.push('G21 G90')
    lines.push('$32=1')
    lines.push('M4 S0')
    lines.push('G0 X0.000 Y0.000')
    lines.push('')
    lines.push('; Raster scan (simplified representation)')
    lines.push('; Full output would contain ' + (stats ? stats.lines : '?') + ' scan lines')
    lines.push('')

    // Show first few lines as example
    const mmPerPx = 25.4 / dpi
    const exampleLines = Math.min(5, stats ? stats.lines : 5)
    for (let l = 0; l < exampleLines; l++) {
      const y = (l * mmPerPx).toFixed(3)
      const flip = bidir && l % 2 === 1
      const S = Math.round(power / 100 * 1000)
      lines.push('G0 Y' + y)
      lines.push(`G1 X${flip ? '0.000' : '100.000'} S${S} F${Math.round(speed * 60)}`)
    }
    lines.push('; ... (' + (stats ? stats.lines - exampleLines : '?') + ' more lines)')
    lines.push('')
    lines.push('M5')
    lines.push('G0 X0.000 Y0.000')
    lines.push('M30')
    return lines.join('\n')
  }

  function fmtTime(secs) {
    if (secs < 60) return secs + 's'
    if (secs < 3600) return Math.floor(secs/60) + 'm ' + (secs%60) + 's'
    return Math.floor(secs/3600) + 'h ' + Math.floor((secs%3600)/60) + 'm'
  }

  return (
    <div className="raster-tab">

      <div className="raster-left">

        {/* Drop zone */}
        <div
          className={`raster-dropzone ${dragging ? 'dragging' : ''} ${image ? 'has-image' : ''}`}
          onDragOver={e => { e.preventDefault(); setDragging(true) }}
          onDragLeave={() => setDragging(false)}
          onDrop={e => { e.preventDefault(); setDragging(false); loadImageFile(e.dataTransfer.files[0]) }}
          onClick={() => fileInputRef.current.click()}
        >
          <input ref={fileInputRef} type="file" accept="image/*" style={{ display:'none' }} onChange={e => loadImageFile(e.target.files[0])} />
          {image ? (
            <div className="drop-loaded">
              <span className="drop-loaded-name">{fileName}</span>
              <span className="drop-loaded-sub">Click to replace</span>
            </div>
          ) : (
            <div className="drop-empty">
              <div className="drop-icon">⬛</div>
              <div className="drop-label">Drop image here</div>
              <div className="drop-sub">PNG, JPG, BMP — any size</div>
            </div>
          )}
        </div>

        {/* Image adjustments */}
        <div className="raster-section">
          <span className="raster-label">Image</span>
          <div className="raster-adj-row">
            <div className="raster-adj">
              <span>Brightness</span>
              <input type="range" min={-50} max={50} value={brightness} onChange={e => setBrightness(Number(e.target.value))} />
              <span className="mono">{brightness > 0 ? '+' : ''}{brightness}</span>
            </div>
            <div className="raster-adj">
              <span>Contrast</span>
              <input type="range" min={-50} max={50} value={contrast} onChange={e => setContrast(Number(e.target.value))} />
              <span className="mono">{contrast > 0 ? '+' : ''}{contrast}</span>
            </div>
          </div>
          <label className="raster-toggle">
            <input type="checkbox" checked={invert} onChange={e => setInvert(e.target.checked)} />
            <span>Invert (engrave light areas)</span>
          </label>
        </div>

        {/* Dither */}
        <div className="raster-section">
          <span className="raster-label">Dithering</span>
          {DITHER_MODES.map(d => (
            <button
              key={d.id}
              className={`dither-btn ${dither === d.id ? 'active' : ''}`}
              onClick={() => setDither(d.id)}
            >
              <div className="dither-btn-name">{d.label}</div>
              <div className="dither-btn-desc">{d.desc}</div>
            </button>
          ))}
        </div>

        {/* Scan settings */}
        <div className="raster-section">
          <span className="raster-label">Scan</span>
          <div className="raster-row">
            <span className="raster-field-label">DPI</span>
            <div className="dpi-options">
              {DPI_OPTIONS.map(d => (
                <button
                  key={d}
                  className={`dpi-btn ${dpi === d ? 'active' : ''}`}
                  onClick={() => setDpi(d)}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>
          <div className="raster-row">
            <span className="raster-field-label">Direction</span>
            <div className="dir-options">
              {[['x','X axis →'],['y','Y axis ↑']].map(([id, label]) => (
                <button key={id} className={`dpi-btn ${scanDir === id ? 'active' : ''}`} onClick={() => setScanDir(id)}>
                  {label}
                </button>
              ))}
            </div>
          </div>
          <label className="raster-toggle">
            <input type="checkbox" checked={bidir} onChange={e => setBidir(e.target.checked)} />
            <span>Bidirectional scanning (faster, slight quality trade-off)</span>
          </label>
        </div>

        {/* Laser settings */}
        <div className="raster-section">
          <span className="raster-label">Laser</span>
          <div className="raster-row">
            <span className="raster-field-label">Power</span>
            <input type="range" min={1} max={100} value={power} onChange={e => setPower(Number(e.target.value))} className="raster-slider" />
            <span className="mono raster-val">{power}%</span>
          </div>
          <div className="raster-row">
            <span className="raster-field-label">Speed</span>
            <input type="range" min={10} max={500} value={speed} onChange={e => setSpeed(Number(e.target.value))} className="raster-slider" />
            <span className="mono raster-val">{speed}mm/s</span>
          </div>
        </div>

      </div>

      {/* Right — preview + stats */}
      <div className="raster-right">
        <span className="raster-label">Preview</span>
        <div className="raster-preview-wrap">
          <canvas ref={previewRef} width={380} height={280} className="raster-preview" />
          {!image && (
            <div className="raster-preview-empty">Load an image to preview</div>
          )}
        </div>

        {stats && (
          <div className="raster-stats">
            {[
              ['Scan lines', stats.lines],
              ['Resolution', stats.resolution],
              ['Output size', stats.width + '×' + stats.height + 'mm'],
              ['Est. time', fmtTime(stats.estimatedSecs)],
            ].map(([label, val]) => (
              <div key={label} className="raster-stat">
                <span className="raster-stat-label">{label}</span>
                <span className="raster-stat-val mono">{val}</span>
              </div>
            ))}
          </div>
        )}

        <div className="raster-actions">
          <button
            className="btn btn-ghost btn-sm"
            disabled={!gcodeReady}
            onClick={() => {
              setPreviewCode(generateGcode())
              setShowCode(v => !v)
            }}
          >
            {showCode ? 'Hide' : 'Preview'} G-code
          </button>
          <button
            className="btn btn-amber"
            disabled={!connected || !gcodeReady}
          >
            ▶ Start Raster Job
          </button>
        </div>

        {showCode && previewCode && (
          <div className="raster-code">
            <div className="raster-code-scroll">
              {previewCode.split('\n').map((line, i) => (
                <div key={i} style={{ color: line.startsWith(';') ? 'var(--t3)' : 'var(--t2)' }}>
                  {line || '\u00a0'}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
