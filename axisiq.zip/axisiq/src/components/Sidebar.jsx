import ConnectionPanel from './ConnectionPanel'
import MachineStatus from './MachineStatus'
import JogControls from './JogControls'
import './Sidebar.css'

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <ConnectionPanel />
      <MachineStatus />
      <JogControls />
    </aside>
  )
}
