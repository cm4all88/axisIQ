import { useState, useEffect, useRef, useCallback } from 'react'
import { useMachineStore } from '../store'
import './CameraTab.css'

const api = window.axisiq

// ── Calibration helpers ───────────────────────────────────────────────────────
// Maps machine XY coords → video pixel coords using two calibration points

function makeCalibration(p1Machine, p1Pixel, p2Machine, p2Pixel) {
  const scaleX = (p2Pixel.x - p1Pixel.x) / (p2Machine.x - p1Machine.x)
  const scaleY = (p2Pixel.y - p1Pixel.y) / (p2Machine.y - p1Machine.y)
  return {
    toPixel(mx, my) {
      return {
        px: p1Pixel.x + (mx - p1Machine.x) * scaleX,
        py: p1Pixel.y + (my - p1Machine.y) * scaleY,
      }
    },
    isValid: true,
  }
}

const DEFAULT_CAL = {
  toPixel(mx, my, videoW, videoH, profile) {
    // Fallback: assume camera covers the full work area
    return {
      px: (mx / (profile.width || 800)) * videoW,
      py: videoH - (my / (profile.depth || 400)) * videoH,
    }
  },
  isValid: false,
}

// ── Fire detection ─────────────────────────────────────────────────────────────

class FireDetector {
  constructor(sensitivity = 0.6) {
    this.baseline    = null
    this.sensitivity = sensitivity  // 0-1, higher = more sensitive
    this.threshold   = 30 + (1 - sensitivity) * 60  // brightness delta threshold
  }

  setBaseline(imageData) {
    this.baseline = this._avgBrightness(imageData)
  }

  analyze(imageData) {
    if (!this.baseline) return { risk: 0, triggered: false }
    const current = this._avgBrightness(imageData)
    const delta   = current - this.baseline
    const risk    = Math.max(0, Math.min(1, delta / this.threshold))
    return { risk, triggered: risk > 0.85, delta, current, baseline: this.baseline }
  }

  _avgBrightness(imageData) {
    const d = imageData.data
    let total = 0
    // Sample every 8th pixel for performance
    for (let i = 0; i < d.length; i += 32) {
      total += (d[i] * 0.299 + d[i+1] * 0.587 + d[i+2] * 0.114)
    }
    return total / (d.length / 32)
  }

  setSensitivity(s) {
    this.sensitivity = s
    this.threshold   = 30 + (1 - s) * 60
  }
}

// ── Time lapse ─────────────────────────────────────────────────────────────────

export default function CameraTab() {
  const {
    position, machineState, machineType,
    gcodeLines, currentLine, jobRunning, jobProgress,
    profile, laserPower, laserSpeed,
  } = useMachineStore()

  // Camera state
  const [cameras,     setCameras]     = useState([])
  const [selectedCam, setSelectedCam] = useState('')
  const [streaming,   setStreaming]   = useState(false)
  const [error,       setError]       = useState('')

  // Overlay state
  const [showCrosshair, setShowCrosshair] = useState(true)
  const [showBounds,    setShowBounds]    = useState(true)
  const [showGrid,      setShowGrid]      = useState(false)
  const [showInfo,      setShowInfo]      = useState(true)
  const [calibrating,   setCalibrating]   = useState(false)
  const [calibPoints,   setCalibPoints]   = useState([])
  const [calibration,   setCalibration]   = useState(DEFAULT_CAL)

  // Time lapse state
  const [tlEnabled,   setTlEnabled]   = useState(false)
  const [tlMode,      setTlMode]      = useState('time')  // 'time' | 'progress'
  const [tlInterval,  setTlInterval]  = useState(10)      // seconds
  const [tlProgress,  setTlProgress]  = useState(5)       // every N%
  const [tlFrames,    setTlFrames]    = useState([])
  const [tlRunning,   setTlRunning]   = useState(false)
  const [tlLastPct,   setTlLastPct]   = useState(0)
  const [exporting,   setExporting]   = useState(false)

  // Fire detection state
  const [fireEnabled,   setFireEnabled]   = useState(machineType === 'co2')
  const [fireSens,      setFireSens]      = useState(0.6)
  const [fireRisk,      setFireRisk]      = useState(0)
  const [fireTriggered, setFireTriggered] = useState(false)
  const [fireBaseline,  setFireBaseline]  = useState(false)

  const videoRef    = useRef(null)
  const overlayRef  = useRef(null)
  const captureRef  = useRef(null)  // offscreen canvas for capture
  const streamRef   = useRef(null)
  const tlTimerRef  = useRef(null)
  const animRef     = useRef(null)
  const detectorRef = useRef(new FireDetector(0.6))
  const lastTlTime  = useRef(0)

  // ── Camera enumeration ──────────────────────────────────────────────────────

  useEffect(() => {
    async function getCameras() {
      try {
        // Request permission first
        await navigator.mediaDevices.getUserMedia({ video: true }).then(s => s.getTracks().forEach(t => t.stop()))
        const devices = await navigator.mediaDevices.enumerateDevices()
        const cams    = devices.filter(d => d.kind === 'videoinput')
        setCameras(cams)
        if (cams.length && !selectedCam) setSelectedCam(cams[0].deviceId)
      } catch (e) {
        setError('Camera access denied. Check permissions.')
      }
    }
    getCameras()
    return () => stopCamera()
  }, [])

  // ── Start / stop camera ─────────────────────────────────────────────────────

  async function startCamera(deviceId) {
    stopCamera()
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { deviceId: deviceId ? { exact: deviceId } : undefined, width: { ideal: 1280 }, height: { ideal: 720 } },
      })
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        videoRef.current.play()
      }
      streamRef.current = stream
      setStreaming(true)
      setError('')
      startOverlayLoop()
    } catch (e) {
      setError(`Could not start camera: ${e.message}`)
    }
  }

  function stopCamera() {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop())
      streamRef.current = null
    }
    if (animRef.current) cancelAnimationFrame(animRef.current)
    setStreaming(false)
  }

  useEffect(() => {
    if (selectedCam) startCamera(selectedCam)
    return () => stopCamera()
  }, [selectedCam])

  // ── Overlay render loop ─────────────────────────────────────────────────────

  function startOverlayLoop() {
    function draw() {
      const video   = videoRef.current
      const overlay = overlayRef.current
      if (!video || !overlay || !video.videoWidth) {
        animRef.current = requestAnimationFrame(draw)
        return
      }

      const W = video.videoWidth, H = video.videoHeight
      if (overlay.width !== W || overlay.height !== H) {
        overlay.width  = W
        overlay.height = H
      }

      const ctx = overlay.getContext('2d')
      ctx.clearRect(0, 0, W, H)

      // Grid overlay
      if (showGrid) drawGrid(ctx, W, H)

      // Machine bounds
      const bbox = parseBoundsFromCode(gcodeLines)
      if (showBounds && bbox) drawBounds(ctx, W, H, bbox)

      // Position crosshair
      if (showCrosshair) drawCrosshair(ctx, W, H)

      // Info overlay
      if (showInfo) drawInfo(ctx, W, H)

      // Fire detection
      if (fireEnabled && streaming) {
        const offscreen = document.createElement('canvas')
        offscreen.width = 64; offscreen.height = 36
        const oc = offscreen.getContext('2d')
        oc.drawImage(video, 0, 0, 64, 36)
        const imageData = oc.getImageData(0, 0, 64, 36)

        if (!fireBaseline) {
          // Will be set when baseline button is clicked
        } else {
          const result = detectorRef.current.analyze(imageData)
          setFireRisk(result.risk)
          if (result.triggered && !fireTriggered) {
            setFireTriggered(true)
            handleFireDetected()
          }
        }
      }

      // Time lapse capture (time-based)
      if (tlRunning && tlMode === 'time') {
        const now = Date.now()
        if (now - lastTlTime.current >= tlInterval * 1000) {
          captureFrame()
          lastTlTime.current = now
        }
      }

      animRef.current = requestAnimationFrame(draw)
    }
    animRef.current = requestAnimationFrame(draw)
  }

  function drawGrid(ctx, W, H) {
    ctx.strokeStyle = 'rgba(255,255,255,0.12)'
    ctx.lineWidth   = 0.5
    const cols = 8, rows = 6
    for (let i = 1; i < cols; i++) { const x = i * W / cols; ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke() }
    for (let i = 1; i < rows; i++) { const y = i * H / rows; ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke() }
    // Center crosshair
    ctx.strokeStyle = 'rgba(255,255,255,0.25)'
    ctx.lineWidth   = 1
    ctx.setLineDash([4,4])
    ctx.beginPath(); ctx.moveTo(W/2,0); ctx.lineTo(W/2,H); ctx.stroke()
    ctx.beginPath(); ctx.moveTo(0,H/2); ctx.lineTo(W,H/2); ctx.stroke()
    ctx.setLineDash([])
  }

  function drawBounds(ctx, W, H, bbox) {
    const isLaser = machineType === 'co2'
    const color   = isLaser ? 'rgba(96,152,208,0.8)' : 'rgba(240,160,48,0.8)'
    const { px: x1, py: y1 } = calibration.toPixel(bbox.minX, bbox.maxY, W, H, profile)
    const { px: x2, py: y2 } = calibration.toPixel(bbox.maxX, bbox.minY, W, H, profile)

    ctx.strokeStyle = color
    ctx.lineWidth   = 2
    ctx.setLineDash([6, 4])
    ctx.strokeRect(x1, y1, x2 - x1, y2 - y1)
    ctx.setLineDash([])

    // Corner marks
    const cs = 10
    ctx.strokeStyle = color
    ctx.lineWidth   = 2
    for (const [cx, cy] of [[x1,y1],[x2,y1],[x2,y2],[x1,y2]]) {
      ctx.strokeRect(cx - cs/2, cy - cs/2, cs, cs)
    }

    // Dimension label
    const w = (bbox.maxX - bbox.minX).toFixed(1)
    const h = (bbox.maxY - bbox.minY).toFixed(1)
    ctx.fillStyle = color
    ctx.font      = '11px JetBrains Mono, monospace'
    ctx.fillText(`${w} × ${h} mm`, x1 + 4, y1 - 4)
  }

  function drawCrosshair(ctx, W, H) {
    const isLaser = machineType === 'co2'
    const color   = isLaser ? '#60a0e0' : '#f0a030'
    const { px, py } = calibration.toPixel(position.x, position.y, W, H, profile)

    if (px < 0 || px > W || py < 0 || py > H) return

    const size = 18

    // Crosshair lines
    ctx.strokeStyle = color
    ctx.lineWidth   = 1.5
    ctx.beginPath(); ctx.moveTo(px - size, py); ctx.lineTo(px - 4, py); ctx.stroke()
    ctx.beginPath(); ctx.moveTo(px + 4, py);    ctx.lineTo(px + size, py); ctx.stroke()
    ctx.beginPath(); ctx.moveTo(px, py - size); ctx.lineTo(px, py - 4); ctx.stroke()
    ctx.beginPath(); ctx.moveTo(px, py + 4);    ctx.lineTo(px, py + size); ctx.stroke()

    // Center dot
    ctx.beginPath(); ctx.arc(px, py, 3, 0, Math.PI * 2)
    ctx.fillStyle = color; ctx.fill()

    // Position label
    ctx.fillStyle    = color
    ctx.font         = '11px JetBrains Mono, monospace'
    ctx.fillText(`X${position.x.toFixed(2)} Y${position.y.toFixed(2)}`, px + 10, py - 6)
  }

  function drawInfo(ctx, W, H) {
    // Bottom-left info bar
    const barH = 28
    ctx.fillStyle = 'rgba(0,0,0,0.55)'
    ctx.fillRect(0, H - barH, W, barH)

    ctx.fillStyle = '#e2e0d8'
    ctx.font      = '11px JetBrains Mono, monospace'

    const state = machineState
    const stateColor = state === 'Run' ? '#f0a030' : state === 'Alarm' ? '#d96060' : '#5ab878'
    ctx.fillStyle = stateColor
    ctx.fillText(state, 10, H - 8)

    if (machineType === 'co2' && jobRunning) {
      ctx.fillStyle = '#e2e0d8'
      ctx.fillText(`P ${laserPower}%  S ${laserSpeed}mm/s`, 80, H - 8)
    }

    if (jobRunning) {
      ctx.fillStyle = '#f0a030'
      ctx.fillText(`${jobProgress}%`, W - 45, H - 8)
    }

    // Timestamp
    ctx.fillStyle = '#56544e'
    ctx.fillText(new Date().toLocaleTimeString('en-US', { hour12: false }), W / 2 - 25, H - 8)

    // Time lapse indicator
    if (tlRunning) {
      ctx.fillStyle = '#d96060'
      ctx.beginPath(); ctx.arc(W - 16, H - 42, 6, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = '#e2e0d8'
      ctx.font      = '10px Inter Tight, sans-serif'
      ctx.fillText(`REC  ${tlFrames.length}f`, W - 72, H - 37)
    }
  }

  // ── Bounding box from gcode ─────────────────────────────────────────────────

  function parseBoundsFromCode(lines) {
    if (!lines || !lines.length) return null
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity
    let px = 0, py = 0, abs = true
    for (const raw of lines) {
      const l = raw.split(';')[0].toUpperCase().trim()
      if (l.includes('G90')) { abs = true; continue }
      if (l.includes('G91')) { abs = false; continue }
      if (!l.match(/^[Gg][0123]/)) continue
      const xm = l.match(/X(-?\d+\.?\d*)/), ym = l.match(/Y(-?\d+\.?\d*)/)
      if (!xm && !ym) continue
      const nx = xm ? (abs ? parseFloat(xm[1]) : px + parseFloat(xm[1])) : px
      const ny = ym ? (abs ? parseFloat(ym[1]) : py + parseFloat(ym[1])) : py
      minX = Math.min(minX, nx); maxX = Math.max(maxX, nx)
      minY = Math.min(minY, ny); maxY = Math.max(maxY, ny)
      px = nx; py = ny
    }
    return minX === Infinity ? null : { minX, maxX, minY, maxY }
  }

  // ── Frame capture ──────────────────────────────────────────────────────────

  function captureFrame() {
    const video   = videoRef.current
    const overlay = overlayRef.current
    if (!video || !video.videoWidth) return

    const W = video.videoWidth, H = video.videoHeight
    const cap = captureRef.current || document.createElement('canvas')
    cap.width = W; cap.height = H
    captureRef.current = cap

    const ctx = cap.getContext('2d')
    ctx.drawImage(video, 0, 0, W, H)
    ctx.drawImage(overlay, 0, 0, W, H)

    cap.toBlob(blob => {
      if (!blob) return
      const url  = URL.createObjectURL(blob)
      const meta = {
        url,
        time: Date.now(),
        line: currentLine,
        progress: jobProgress,
        position: { ...position },
      }
      setTlFrames(f => [...f, meta])
    }, 'image/jpeg', 0.82)
  }

  // Progress-based capture
  useEffect(() => {
    if (!tlRunning || tlMode !== 'progress') return
    const threshold = Math.floor(jobProgress / tlProgress) * tlProgress
    if (threshold > tlLastPct && jobProgress > 0) {
      captureFrame()
      setTlLastPct(threshold)
    }
  }, [jobProgress, tlRunning, tlMode])

  // Start / stop time lapse
  function toggleTimeLapse() {
    if (tlRunning) {
      setTlRunning(false)
      lastTlTime.current = 0
    } else {
      setTlFrames([])
      setTlLastPct(0)
      lastTlTime.current = Date.now()
      setTlRunning(true)
      captureFrame() // First frame immediately
    }
  }

  // ── Fire detection ─────────────────────────────────────────────────────────

  function setFireBaselineNow() {
    const video = videoRef.current
    if (!video || !video.videoWidth) return
    const off = document.createElement('canvas')
    off.width = 64; off.height = 36
    const ctx = off.getContext('2d')
    ctx.drawImage(video, 0, 0, 64, 36)
    const imageData = ctx.getImageData(0, 0, 64, 36)
    detectorRef.current.setBaseline(imageData)
    setFireBaseline(true)
    setFireRisk(0)
    setFireTriggered(false)
  }

  async function handleFireDetected() {
    captureFrame()
    await api?.stopStream()
    await api?.send('M5')
    addLog && addLog({ type: 'error', text: '🔥 FIRE DETECTED — machine stopped', time: Date.now() })
  }

  function resetFire() {
    setFireTriggered(false)
    setFireRisk(0)
    setFireBaselineNow()
  }

  // ── Export ─────────────────────────────────────────────────────────────────

  async function exportTimeLapse() {
    if (!tlFrames.length) return
    setExporting(true)

    // In Electron: send frames to main process → FFmpeg
    // For now, trigger download of frames as ZIP or GIF
    // Real implementation: IPC call to main.js ffmpeg handler
    await api?.send?.('timelapse:compile', { frameCount: tlFrames.length })
      .catch(() => null)

    // Fallback: download the last captured frame
    const last = tlFrames[tlFrames.length - 1]
    if (last) {
      const a = document.createElement('a')
      a.href     = last.url
      a.download = `axisiq-timelapse-frame-${tlFrames.length}.jpg`
      a.click()
    }

    setExporting(false)
  }

  // ── Calibration ────────────────────────────────────────────────────────────

  function handleCalibClick(e) {
    if (!calibrating) return
    const canvas = overlayRef.current
    if (!canvas) return
    const rect = canvas.getBoundingClientRect()
    const px   = (e.clientX - rect.left) * (canvas.width / rect.width)
    const py   = (e.clientY - rect.top)  * (canvas.height / rect.height)

    if (calibPoints.length === 0) {
      setCalibPoints([{ pixel: { x: px, y: py }, machine: { x: position.x, y: position.y } }])
    } else if (calibPoints.length === 1) {
      const p1 = calibPoints[0]
      const p2 = { pixel: { x: px, y: py }, machine: { x: position.x, y: position.y } }
      const cal = makeCalibration(p1.machine, p1.pixel, p2.machine, p2.pixel)
      setCalibration(cal)
      setCalibPoints([])
      setCalibrating(false)
    }
  }

  // ── Render ─────────────────────────────────────────────────────────────────

  const isLaser    = machineType === 'co2'
  const accentColor = isLaser ? 'var(--blue)' : 'var(--amber)'

  return (
    <div className="camera-tab">

      {/* Main camera view */}
      <div className="camera-main">

        {/* Video + overlay stack */}
        <div className="camera-viewport" onClick={handleCalibClick}>
          {!streaming && (
            <div className="camera-placeholder">
              {error
                ? <div className="cam-error">{error}</div>
                : <div className="cam-loading">
                    <div className="cam-loading-icon">◉</div>
                    <span>Starting camera…</span>
                  </div>
              }
            </div>
          )}
          <video
            ref={videoRef}
            className="camera-video"
            muted
            playsInline
            style={{ display: streaming ? 'block' : 'none' }}
          />
          <canvas
            ref={overlayRef}
            className="camera-overlay"
            style={{ cursor: calibrating ? 'crosshair' : 'default' }}
          />

          {/* Fire alert overlay */}
          {fireTriggered && (
            <div className="fire-overlay">
              <div className="fire-overlay-inner">
                <span className="fire-overlay-icon">🔥</span>
                <span className="fire-overlay-text">FIRE DETECTED</span>
                <span className="fire-overlay-sub">Machine stopped</span>
                <button className="btn btn-sm" onClick={resetFire}>Clear &amp; Reset</button>
              </div>
            </div>
          )}

          {/* Calibration prompt */}
          {calibrating && (
            <div className="cal-prompt">
              {calibPoints.length === 0
                ? 'Jog to a known position, then click that location on the video'
                : 'Jog to a second known position, then click it'}
            </div>
          )}

          {/* Recording indicator */}
          {tlRunning && (
            <div className="rec-badge">
              <span className="rec-dot" />
              REC · {tlFrames.length} frames
            </div>
          )}
        </div>

        {/* Overlay toggles */}
        <div className="cam-toggles">
          {[
            ['⊕ Position', showCrosshair, setShowCrosshair],
            ['□ Bounds',   showBounds,    setShowBounds],
            ['⊞ Grid',     showGrid,      setShowGrid],
            ['ℹ Info',     showInfo,      setShowInfo],
          ].map(([label, on, set]) => (
            <button
              key={label}
              className={`cam-toggle ${on ? 'cam-toggle-on' : ''}`}
              onClick={() => set(v => !v)}
              style={{ '--ac': accentColor }}
            >
              {label}
            </button>
          ))}

          {/* Camera selector */}
          <select
            value={selectedCam}
            onChange={e => setSelectedCam(e.target.value)}
            className="cam-select"
          >
            {cameras.map(c => (
              <option key={c.deviceId} value={c.deviceId}>
                {c.label || `Camera ${cameras.indexOf(c) + 1}`}
              </option>
            ))}
          </select>

          <button
            className={`cam-toggle ${calibrating ? 'cam-toggle-on' : ''}`}
            onClick={() => { setCalibrating(v => !v); setCalibPoints([]) }}
          >
            ◈ Calibrate
          </button>

          {!streaming
            ? <button className="btn btn-amber btn-sm" onClick={() => startCamera(selectedCam)}>Start Camera</button>
            : <button className="btn btn-sm" onClick={stopCamera}>Stop</button>
          }
        </div>

        {/* Frame strip */}
        {tlFrames.length > 0 && (
          <div className="frame-strip">
            {tlFrames.slice(-12).map((f, i) => (
              <div key={i} className="frame-thumb-wrap">
                <img src={f.url} className="frame-thumb" alt={`Frame ${i}`} />
                <span className="frame-thumb-label">{f.progress}%</span>
              </div>
            ))}
            <button className="frame-export-btn" onClick={exportTimeLapse} disabled={exporting}>
              {exporting ? '…' : '⬇ Export'}
            </button>
          </div>
        )}
      </div>

      {/* Right panel */}
      <div className="camera-panel">

        {/* Time lapse */}
        <div className="cam-section">
          <div className="cam-section-head">
            <span className="cam-section-title">Time Lapse</span>
            <div className={`tl-indicator ${tlRunning ? 'tl-on' : ''}`}>
              <span className="tl-dot" />
              {tlRunning ? 'Recording' : 'Stopped'}
            </div>
          </div>

          <div className="tl-mode-row">
            {[['time','Every N seconds'],['progress','Every N% of job']].map(([id, label]) => (
              <button
                key={id}
                className={`tl-mode-btn ${tlMode === id ? 'tl-active' : ''}`}
                onClick={() => setTlMode(id)}
                disabled={tlRunning}
              >
                {label}
              </button>
            ))}
          </div>

          {tlMode === 'time' && (
            <div className="cam-field">
              <label>Interval</label>
              <div className="cam-input-row">
                <input
                  type="number" min={1} max={300} value={tlInterval}
                  onChange={e => setTlInterval(Number(e.target.value))}
                  disabled={tlRunning}
                />
                <span className="cam-unit">sec</span>
              </div>
            </div>
          )}

          {tlMode === 'progress' && (
            <div className="cam-field">
              <label>Capture every</label>
              <div className="cam-input-row">
                <input
                  type="number" min={1} max={25} value={tlProgress}
                  onChange={e => setTlProgress(Number(e.target.value))}
                  disabled={tlRunning}
                />
                <span className="cam-unit">% progress</span>
              </div>
            </div>
          )}

          <div className="tl-stats">
            <div>
              <span className="tl-stat-label">Frames</span>
              <strong>{tlFrames.length}</strong>
            </div>
            <div>
              <span className="tl-stat-label">~Duration</span>
              <strong>{Math.round(tlFrames.length / 24)}s at 24fps</strong>
            </div>
          </div>

          <div className="tl-actions">
            <button
              className={`btn ${tlRunning ? 'btn-red' : 'btn-amber'}`}
              onClick={toggleTimeLapse}
              disabled={!streaming}
            >
              {tlRunning ? '■ Stop' : '● Start Lapse'}
            </button>
            {tlFrames.length > 0 && (
              <button className="btn btn-sm" onClick={() => setTlFrames([])}>
                Clear
              </button>
            )}
          </div>

          {tlFrames.length > 0 && (
            <button className="btn btn-sm tl-export" onClick={exportTimeLapse} disabled={exporting || !tlFrames.length}>
              ⬇ Export MP4
            </button>
          )}
        </div>

        {/* Fire detection */}
        {isLaser && (
          <div className="cam-section">
            <div className="cam-section-head">
              <span className="cam-section-title">🔥 Fire Detection</span>
              <div className="cam-toggle-switch" onClick={() => setFireEnabled(v => !v)}>
                <div className={`cts-track ${fireEnabled ? 'cts-on' : ''}`}>
                  <div className="cts-thumb" />
                </div>
              </div>
            </div>

            {fireEnabled && (
              <>
                <div className="fire-meter-wrap">
                  <div className="fire-meter">
                    <div
                      className="fire-meter-fill"
                      style={{
                        width: (fireRisk * 100) + '%',
                        background: fireRisk > 0.7 ? 'var(--red)' : fireRisk > 0.4 ? '#d4aa40' : 'var(--green)',
                      }}
                    />
                  </div>
                  <span className="fire-meter-label">
                    {fireRisk < 0.1 ? 'Safe' : fireRisk < 0.4 ? 'Elevated' : fireRisk < 0.7 ? 'Warning' : 'DANGER'}
                  </span>
                </div>

                <div className="cam-field">
                  <label>Sensitivity</label>
                  <input
                    type="range" min={0.1} max={1} step={0.05} value={fireSens}
                    onChange={e => {
                      setFireSens(Number(e.target.value))
                      detectorRef.current.setSensitivity(Number(e.target.value))
                    }}
                    className="fire-slider"
                  />
                  <div className="fire-sens-labels">
                    <span>Low</span><span>High</span>
                  </div>
                </div>

                <div className="fire-actions">
                  <button
                    className="btn btn-sm"
                    onClick={setFireBaselineNow}
                    disabled={!streaming}
                    title="Capture current brightness as the 'safe' baseline"
                  >
                    {fireBaseline ? '↺ Reset Baseline' : '◉ Set Baseline'}
                  </button>
                  {!fireBaseline && (
                    <span className="fire-no-baseline">Set baseline before running</span>
                  )}
                </div>

                <p className="fire-hint">
                  Compares each frame to the baseline. A sudden brightness spike triggers feed hold and laser off. Set baseline after material is loaded and positioned.
                </p>
              </>
            )}
          </div>
        )}

        {/* AI vision */}
        <div className="cam-section">
          <div className="cam-section-head">
            <span className="cam-section-title">✦ AI Vision</span>
            <span className="cam-beta-badge">beta</span>
          </div>
          <p className="cam-hint">Periodically sends a frame to Claude and asks if the job looks correct. Flags misalignment, burn patterns, or material shift.</p>
          <div className="ai-vision-actions">
            <button className="btn btn-sm" disabled={!streaming}>
              Analyze Frame Now
            </button>
            <div className="cam-field" style={{ marginTop: 8 }}>
              <label>Auto-check every</label>
              <div className="cam-input-row">
                <input type="number" min={30} max={300} defaultValue={60} />
                <span className="cam-unit">sec</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}
