import { useState, useRef, useEffect } from 'react'
import { useMachineStore } from '../store'
import './AIPanel.css'

const QUICK_PROMPTS = [
  { label: 'Feed & Speed',     text: 'What feed rate and spindle speed should I use for a ¼" end mill in MDF?' },
  { label: 'DOC Advice',       text: 'What is a safe depth of cut for a ¼" upcut spiral bit in plywood?' },
  { label: 'Check My G-code',  text: 'Review my G-code for any issues or potential crashes.' },
  { label: 'Fixture Setup',    text: 'How should I hold down a 12x12" piece of thin plywood for routing?' },
  { label: 'Z Zeroing',        text: 'Explain the best way to set Z zero on a wood router.' },
  { label: 'Climb vs Conv',    text: 'When should I use climb milling vs conventional milling on a wood router?' },
]

export default function AIPanel() {
  const { gcodeLines, fileName, profile, position, machineState } = useMachineStore()
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('axisiq_api_key') || '')
  const [showKeyInput, setShowKeyInput] = useState(false)
  const messagesRef = useRef(null)

  useEffect(() => {
    if (messagesRef.current) {
      messagesRef.current.scrollTop = messagesRef.current.scrollHeight
    }
  }, [messages])

  function saveKey(key) {
    setApiKey(key)
    localStorage.setItem('axisiq_api_key', key)
    setShowKeyInput(false)
  }

  function buildContext() {
    const parts = [`You are an expert CNC machinist and G-code programmer assisting with a wood router.`]
    parts.push(`Machine: ${profile.name}, work area ${profile.width}×${profile.depth}×${profile.height}mm.`)
    parts.push(`Current state: ${machineState}. Position X${position.x} Y${position.y} Z${position.z}.`)
    if (fileName) {
      parts.push(`Loaded file: ${fileName} (${gcodeLines.length} lines).`)
      if (gcodeLines.length > 0) {
        parts.push(`First 20 lines:\n${gcodeLines.slice(0, 20).join('\n')}`)
      }
    }
    parts.push(`Be practical and direct. Use specific numbers, not vague ranges. Flag any safety concerns clearly.`)
    return parts.join('\n')
  }

  async function sendMessage(text) {
    const userText = text || input.trim()
    if (!userText || loading) return
    if (!apiKey) { setShowKeyInput(true); return }

    setInput('')
    const userMsg = { role: 'user', content: userText }
    const newMessages = [...messages, userMsg]
    setMessages(newMessages)
    setLoading(true)

    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1024,
          system: buildContext(),
          messages: newMessages,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error?.message || 'API error')
      }

      const assistantText = data.content?.[0]?.text || 'No response'
      setMessages(m => [...m, { role: 'assistant', content: assistantText }])
    } catch (err) {
      setMessages(m => [...m, { role: 'assistant', content: `⚠ ${err.message}`, error: true }])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="ai-panel">
      {/* Header */}
      <div className="ai-header">
        <div className="ai-header-left">
          <span className="ai-title">AI Assist</span>
          <span className="ai-model">claude-sonnet</span>
        </div>
        <div className="ai-header-right">
          <button
            className="btn btn-ghost btn-sm"
            onClick={() => setMessages([])}
            title="Clear conversation"
          >
            Clear
          </button>
          <button
            className="btn btn-ghost btn-sm"
            onClick={() => setShowKeyInput(v => !v)}
            title="API key"
          >
            🔑
          </button>
        </div>
      </div>

      {/* API key input */}
      {showKeyInput && (
        <div className="ai-key-row">
          <input
            type="password"
            placeholder="sk-ant-…"
            defaultValue={apiKey}
            onBlur={e => saveKey(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && saveKey(e.target.value)}
            autoFocus
          />
          <span className="ai-key-hint">Stored locally. Never sent anywhere except Anthropic.</span>
        </div>
      )}

      {/* Quick prompts */}
      <div className="ai-quick">
        {QUICK_PROMPTS.map(p => (
          <button
            key={p.label}
            className="btn btn-sm ai-quick-btn"
            onClick={() => sendMessage(p.text)}
            disabled={loading}
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Messages */}
      <div className="ai-messages" ref={messagesRef}>
        {messages.length === 0 && (
          <div className="ai-empty">
            <div className="ai-empty-icon">✦</div>
            <p>Ask anything about feeds, speeds, G-code, fixturing, or material selection.</p>
            <p className="ai-empty-sub">Machine context is included automatically.</p>
          </div>
        )}

        {messages.map((msg, i) => (
          <div key={i} className={`ai-msg ai-msg-${msg.role} ${msg.error ? 'ai-msg-error' : ''}`}>
            <div className="ai-msg-label">{msg.role === 'user' ? 'You' : 'AI'}</div>
            <div className="ai-msg-text">{msg.content}</div>
          </div>
        ))}

        {loading && (
          <div className="ai-msg ai-msg-assistant">
            <div className="ai-msg-label">AI</div>
            <div className="ai-thinking">
              <span />
              <span />
              <span />
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="ai-input-row">
        <textarea
          className="ai-input"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault()
              sendMessage()
            }
          }}
          placeholder={apiKey ? 'Ask a machining question… (Enter to send)' : 'Set API key to enable AI'}
          disabled={loading || !apiKey}
          rows={2}
        />
        <button
          className="btn btn-amber btn-sm ai-send"
          onClick={() => sendMessage()}
          disabled={loading || !input.trim() || !apiKey}
        >
          ↑
        </button>
      </div>
    </div>
  )
}
