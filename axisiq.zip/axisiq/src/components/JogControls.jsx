import { useEffect } from 'react'
import { useMachineStore } from '../store'
import './JogControls.css'

const api = window.axisiq

const STEPS = [0.01, 0.1, 1, 5, 10, 50]
const FEEDS = [100, 500, 1000, 2000, 5000]

export default function JogControls() {
  const { connected, jogStep, jogFeed, setJogStep, setJogFeed, units } = useMachineStore()

  async function jog(axis, dir) {
    if (!connected || !api) return
    const dist = dir * jogStep
    const cmd = `$J=G21G91${axis}${dist.toFixed(4)}F${jogFeed}`
    await api.send(cmd)
  }

  async function cancelJog() {
    await api?.realtime(0x85)
  }

  // Keyboard jogging
  useEffect(() => {
    function onKey(e) {
      if (!connected) return
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return

      const map = {
        ArrowLeft:  () => jog('X', -1),
        ArrowRight: () => jog('X',  1),
        ArrowUp:    () => jog('Y',  1),
        ArrowDown:  () => jog('Y', -1),
        PageUp:     () => jog('Z',  1),
        PageDown:   () => jog('Z', -1),
      }

      if (map[e.key]) {
        e.preventDefault()
        map[e.key]()
      }
    }

    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [connected, jogStep, jogFeed])

  return (
    <div className="panel jog-panel">
      <div className="panel-header">
        <span className="label">Jog</span>
        <span className="label" style={{ color: 'var(--text-3)', fontSize: 9 }}>Arrow keys active</span>
      </div>

      {/* XY pad */}
      <div className="jog-xy">
        <button className="btn jog-btn jog-nw" disabled={!connected} onClick={() => { jog('X',-1); jog('Y',1) }}>↖</button>
        <button className="btn jog-btn jog-n"  disabled={!connected} onClick={() => jog('Y', 1)}>↑</button>
        <button className="btn jog-btn jog-ne" disabled={!connected} onClick={() => { jog('X',1); jog('Y',1) }}>↗</button>
        <button className="btn jog-btn jog-w"  disabled={!connected} onClick={() => jog('X',-1)}>←</button>
        <div className="jog-center">
          <span className="jog-center-text">XY</span>
        </div>
        <button className="btn jog-btn jog-e"  disabled={!connected} onClick={() => jog('X', 1)}>→</button>
        <button className="btn jog-btn jog-sw" disabled={!connected} onClick={() => { jog('X',-1); jog('Y',-1) }}>↙</button>
        <button className="btn jog-btn jog-s"  disabled={!connected} onClick={() => jog('Y',-1)}>↓</button>
        <button className="btn jog-btn jog-se" disabled={!connected} onClick={() => { jog('X',1); jog('Y',-1) }}>↘</button>
      </div>

      {/* Z axis */}
      <div className="jog-z">
        <button className="btn jog-btn" disabled={!connected} onClick={() => jog('Z', 1)}>Z ↑</button>
        <button className="btn jog-btn" disabled={!connected} onClick={() => jog('Z',-1)}>Z ↓</button>
      </div>

      {/* Step size */}
      <div className="jog-section">
        <span className="label">Step ({units})</span>
        <div className="jog-steps">
          {STEPS.map(s => (
            <button
              key={s}
              className={`btn btn-sm jog-step ${jogStep === s ? 'jog-step-active' : ''}`}
              onClick={() => setJogStep(s)}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Feed */}
      <div className="jog-section">
        <span className="label">Feed ({units}/min)</span>
        <div className="jog-steps">
          {FEEDS.map(f => (
            <button
              key={f}
              className={`btn btn-sm jog-step ${jogFeed === f ? 'jog-step-active' : ''}`}
              onClick={() => setJogFeed(f)}
            >
              {f >= 1000 ? `${f/1000}k` : f}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
