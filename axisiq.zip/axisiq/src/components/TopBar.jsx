import { useMachineStore } from '../store'
import './TopBar.css'

const api = window.axisiq

export default function TopBar() {
  const { connected, machineState, firmware, jobRunning, setJobStopped, machineType, setMachineType } = useMachineStore()

  async function handleEStop() {
    await api?.stopStream()
    await api?.realtime(0x18)
    if (machineType === 'co2') await api?.send('M5')
    setJobStopped()
  }

  return (
    <header className="topbar">
      <div className="topbar-left">
        <span className="topbar-logo">
          <span className="topbar-logo-axis">Axis</span>
          <span className="topbar-logo-iq">IQ</span>
        </span>

        {/* Machine type toggle */}
        <div className="machine-type-toggle">
          <button
            className={`mtt-btn ${machineType === 'router' ? 'mtt-active' : ''}`}
            onClick={() => setMachineType('router')}
          >
            ⚙ Router
          </button>
          <button
            className={`mtt-btn ${machineType === 'co2' ? 'mtt-active' : ''}`}
            onClick={() => setMachineType('co2')}
          >
            ⚡ CO₂ Laser
          </button>
        </div>
      </div>

      <div className="topbar-center">
        <span className={`state-pill state-${machineState}`}>
          {machineState}
        </span>
        {firmware && <span className="topbar-firmware">{firmware}</span>}
      </div>

      <div className="topbar-right">
        {(connected && (jobRunning || machineState === 'Run')) && (
          <button className="btn btn-red estop" onClick={handleEStop}>
            ⬛ STOP
          </button>
        )}
      </div>
    </header>
  )
}
