import { useState } from 'react'
import { useMachineStore } from '../store'
import { MATERIAL_DB, CATEGORIES } from '../data/materials'
import './MaterialLibrary.css'

const api = window.axisiq

const OP_LABELS = { cut: 'Cut', engrave: 'Engrave', score: 'Score' }
const OP_COLORS = { cut: 'var(--red)', engrave: 'var(--amber)', score: 'var(--blue)' }

function StarRating({ rating }) {
  const full = Math.floor(rating)
  const half = rating - full >= 0.5
  return (
    <span className="stars">
      {'★'.repeat(full)}
      {half ? '½' : ''}
      {'☆'.repeat(5 - full - (half ? 1 : 0))}
    </span>
  )
}

function SettingRow({ label, value, unit, color }) {
  return (
    <div className="setting-row">
      <span className="setting-label">{label}</span>
      <span className="setting-value mono" style={{ color: color || 'var(--text)' }}>
        {value}
        {unit && <span className="setting-unit"> {unit}</span>}
      </span>
    </div>
  )
}

function OperationCard({ op, data, active, onClick, cannotCut }) {
  if (!data) return null

  const canDo = !(op === 'cut' && cannotCut)
  const label = OP_LABELS[op]
  const color = OP_COLORS[op]

  return (
    <button
      className={`op-card ${active ? 'op-active' : ''} ${!canDo ? 'op-disabled' : ''}`}
      onClick={canDo ? onClick : undefined}
      style={{ '--op-color': color }}
    >
      <div className="op-card-header">
        <span className="op-label" style={{ color: active ? color : 'var(--t2)' }}>
          {label}
        </span>
        {cannotCut && op === 'cut' && (
          <span className="op-warning">CO2 cannot cut</span>
        )}
      </div>

      {canDo && (
        <div className="op-stats">
          <div className="op-stat">
            <span className="op-stat-val">{data.power}%</span>
            <span className="op-stat-key">power</span>
          </div>
          <div className="op-stat">
            <span className="op-stat-val">{data.speed}</span>
            <span className="op-stat-key">mm/s</span>
          </div>
          {op === 'cut' && data.passes > 0 && (
            <div className="op-stat">
              <span className="op-stat-val">{data.passes}</span>
              <span className="op-stat-key">passes</span>
            </div>
          )}
          {op === 'engrave' && data.dpi && (
            <div className="op-stat">
              <span className="op-stat-val">{data.dpi}</span>
              <span className="op-stat-key">dpi</span>
            </div>
          )}
          {data.air !== undefined && (
            <div className="op-stat">
              <span className="op-stat-val" style={{ color: data.air ? 'var(--blue)' : 'var(--t3)' }}>
                {data.air ? '💨' : '—'}
              </span>
              <span className="op-stat-key">air</span>
            </div>
          )}
        </div>
      )}
    </button>
  )
}

export default function MaterialLibrary() {
  const {
    connected,
    setLaserPower, setLaserSpeed, setLaserPasses, setAirAssist,
    setActiveMaterial, setActiveTab,
    addLog,
  } = useMachineStore()

  const [category, setCategory] = useState('all')
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(MATERIAL_DB[0])
  const [activeOp, setActiveOp] = useState('cut')
  const [aiTuning, setAiTuning] = useState(false)
  const [customMode, setCustomMode] = useState(false)
  const [customMat, setCustomMat] = useState({
    name: '', thickness: 3,
    cut: { power: 70, speed: 10, passes: 1, air: true },
    engrave: { power: 25, speed: 100, dpi: 254, air: false },
    score: { power: 12, speed: 150 },
    notes: '',
  })

  const filtered = MATERIAL_DB.filter(m => {
    const matchCat = category === 'all' || m.category === category
    const matchSearch = !search || m.name.toLowerCase().includes(search.toLowerCase())
    return matchCat && matchSearch
  })

  function applySettings() {
    const mat = customMode ? customMat : selected
    const data = mat[activeOp]
    if (!data || (activeOp === 'cut' && selected.cutNote)) return

    setLaserPower(data.power)
    setLaserSpeed(data.speed)
    if (data.passes) setLaserPasses(data.passes)
    if (data.air !== undefined) setAirAssist(data.air)
    setActiveMaterial(mat)

    addLog({
      type: 'info',
      text: `Applied: ${mat.name} ${mat.thickness}mm — ${activeOp} (${data.power}% @ ${data.speed}mm/s)`,
      time: Date.now(),
    })
  }

  const mat = customMode ? customMat : selected

  return (
    <div className="material-library">

      {/* Left: category + list */}
      <div className="mat-sidebar">
        <div className="mat-search-row">
          <input
            placeholder="Search materials…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="mat-search"
          />
        </div>

        <div className="cat-list">
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              className={`cat-btn ${category === cat.id ? 'cat-active' : ''}`}
              onClick={() => setCategory(cat.id)}
            >
              {cat.label}
              <span className="cat-count">
                {cat.id === 'all'
                  ? MATERIAL_DB.length
                  : MATERIAL_DB.filter(m => m.category === cat.id).length}
              </span>
            </button>
          ))}
        </div>

        <div className="mat-list">
          {filtered.map(mat => (
            <button
              key={mat.id}
              className={`mat-item ${selected && selected.id === mat.id && !customMode ? 'mat-active' : ''}`}
              onClick={() => { setSelected(mat); setCustomMode(false) }}
            >
              <div className="mat-item-main">
                <span className="mat-item-name">{mat.name}</span>
                <span className="mat-item-thick mono">{mat.thickness}mm</span>
              </div>
              <div className="mat-item-meta">
                {mat.verified && <span className="mat-verified">✓</span>}
                <StarRating rating={mat.rating} />
                <span className="mat-votes">({mat.votes})</span>
              </div>
            </button>
          ))}

          <button
            className={`mat-item mat-custom-btn ${customMode ? 'mat-active' : ''}`}
            onClick={() => setCustomMode(true)}
          >
            <span className="mat-item-name">+ Custom Material</span>
          </button>
        </div>
      </div>

      {/* Right: detail */}
      <div className="mat-detail">
        {!customMode && selected ? (
          <>
            <div className="mat-detail-header">
              <div>
                <h2 className="mat-detail-name">{selected.name}</h2>
                <div className="mat-detail-meta">
                  <span className="mat-detail-thick">{selected.thickness}mm</span>
                  <span className="mat-detail-cat">{selected.category}</span>
                  {selected.verified && <span className="mat-detail-verified">✓ Verified</span>}
                </div>
              </div>
              <div className="mat-rating-block">
                <StarRating rating={selected.rating} />
                <span className="mat-rating-val">{selected.rating}</span>
                <span className="mat-rating-votes">{selected.votes} votes</span>
              </div>
            </div>

            {/* Operation cards */}
            <div className="op-cards">
              {['cut', 'engrave', 'score'].map(op => (
                <OperationCard
                  key={op}
                  op={op}
                  data={selected[op]}
                  active={activeOp === op}
                  cannotCut={!!selected.cutNote}
                  onClick={() => setActiveOp(op)}
                />
              ))}
            </div>

            {/* Active op detail */}
            <div className="op-detail">
              <div className="op-detail-header">
                <span className="label" style={{ color: OP_COLORS[activeOp] }}>
                  {OP_LABELS[activeOp]} Settings
                </span>
              </div>

              {activeOp === 'cut' && selected.cutNote ? (
                <div className="op-cannot">
                  <span>⚠</span> {selected.cutNote}
                </div>
              ) : (
                <div className="op-detail-grid">
                  <SettingRow label="Power" value={selected[activeOp]?.power + '%'} color={OP_COLORS[activeOp]} />
                  <SettingRow label="Speed" value={selected[activeOp]?.speed} unit="mm/s" />
                  {activeOp === 'cut' && <SettingRow label="Passes" value={selected[activeOp]?.passes} />}
                  {activeOp === 'engrave' && selected[activeOp]?.dpi && <SettingRow label="DPI" value={selected[activeOp].dpi} />}
                  <SettingRow
                    label="Air assist"
                    value={selected[activeOp]?.air ? 'ON' : 'Off'}
                    color={selected[activeOp]?.air ? 'var(--blue)' : 'var(--t3)'}
                  />
                </div>
              )}
            </div>

            {/* Notes */}
            {selected.notes && (
              <div className="mat-notes">
                <span className="label">Notes</span>
                <p>{selected.notes}</p>
              </div>
            )}

            {/* Actions */}
            <div className="mat-actions">
              <button
                className="btn btn-ghost btn-sm"
                onClick={() => {
                  setAiTuning(true)
                  setTimeout(() => setAiTuning(false), 2000)
                }}
              >
                ✦ AI Tune
              </button>
              <button
                className="btn btn-amber"
                onClick={applySettings}
                disabled={!connected || (activeOp === 'cut' && !!selected.cutNote)}
              >
                Apply to Job
              </button>
            </div>

            {aiTuning && (
              <div className="ai-tuning-hint">
                ✦ Opening AI with {selected.name} {selected.thickness}mm context…
              </div>
            )}
          </>
        ) : customMode ? (
          /* Custom material form */
          <div className="custom-mat-form">
            <h2 className="mat-detail-name">Custom Material</h2>
            <p className="custom-mat-hint">Define your own settings for unlisted materials.</p>

            <div className="custom-grid">
              <div className="custom-field">
                <label>Material name</label>
                <input
                  value={customMat.name}
                  onChange={e => setCustomMat(m => ({ ...m, name: e.target.value }))}
                  placeholder="e.g. Basswood 2mm"
                />
              </div>
              <div className="custom-field">
                <label>Thickness (mm)</label>
                <input
                  type="number" min={0.1} step={0.5}
                  value={customMat.thickness}
                  onChange={e => setCustomMat(m => ({ ...m, thickness: Number(e.target.value) }))}
                />
              </div>
            </div>

            {['cut','engrave','score'].map(op => (
              <div key={op} className="custom-op-section">
                <span className="label" style={{ color: OP_COLORS[op] }}>{OP_LABELS[op]}</span>
                <div className="custom-op-grid">
                  <div className="custom-field">
                    <label>Power %</label>
                    <input type="number" min={0} max={100} value={customMat[op].power}
                      onChange={e => setCustomMat(m => ({ ...m, [op]: { ...m[op], power: Number(e.target.value) } }))} />
                  </div>
                  <div className="custom-field">
                    <label>Speed mm/s</label>
                    <input type="number" min={1} value={customMat[op].speed}
                      onChange={e => setCustomMat(m => ({ ...m, [op]: { ...m[op], speed: Number(e.target.value) } }))} />
                  </div>
                  {op === 'cut' && (
                    <div className="custom-field">
                      <label>Passes</label>
                      <input type="number" min={1} max={10} value={customMat[op].passes}
                        onChange={e => setCustomMat(m => ({ ...m, [op]: { ...m[op], passes: Number(e.target.value) } }))} />
                    </div>
                  )}
                </div>
              </div>
            ))}

            <div className="custom-field" style={{ marginTop: 12 }}>
              <label>Notes</label>
              <textarea
                value={customMat.notes}
                onChange={e => setCustomMat(m => ({ ...m, notes: e.target.value }))}
                placeholder="Tips, warnings, source…"
                rows={3}
              />
            </div>

            <div className="mat-actions" style={{ marginTop: 16 }}>
              <button className="btn btn-amber" onClick={applySettings} disabled={!connected || !customMat.name}>
                Apply Custom Settings
              </button>
            </div>
          </div>
        ) : (
          <div className="mat-empty">Select a material to see settings</div>
        )}
      </div>
    </div>
  )
}
