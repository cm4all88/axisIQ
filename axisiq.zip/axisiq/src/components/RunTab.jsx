import { useState } from 'react'
import { useMachineStore } from '../store'
import FramePanel from './FramePanel'
import './RunTab.css'

const api = window.axisiq

export default function RunTab() {
  const {
    connected,
    fileName, gcodeLines, currentLine, jobProgress,
    jobRunning, jobPaused, jobDone,
    loadFile, setJobRunning, setJobPaused, setJobResumed, setJobStopped,
    addLog,
  } = useMachineStore()

  const [framePassed, setFramePassed] = useState(false)

  async function openFile() {
    const result = await api?.openFile()
    if (!result || result.canceled) return
    loadFile({ fileName: result.fileName, lines: result.lines })
    addLog({ type: 'info', text: `Loaded: ${result.fileName} (${result.lines.length} lines)`, time: Date.now() })
  }

  async function startJob() {
    if (!connected || !gcodeLines.length) return
    setJobRunning()
    await api?.startStream(gcodeLines)
  }

  async function pauseJob() {
    setJobPaused()
    await api?.pauseStream()
  }

  async function resumeJob() {
    setJobResumed()
    await api?.resumeStream()
  }

  async function stopJob() {
    setJobStopped()
    await api?.stopStream()
  }

  const linesBefore = gcodeLines.slice(Math.max(0, currentLine - 3), currentLine)
  const currentLineText = gcodeLines[currentLine] || ''
  const linesAfter = gcodeLines.slice(currentLine + 1, currentLine + 4)

  return (
    <div className="run-tab">
      {/* File section */}
      <div className="run-section">
        <div className="run-section-header">
          <span className="label">G-code File</span>
          {fileName && <span className="run-filename">{fileName}</span>}
        </div>

        <div className="run-file-actions">
          <button className="btn" onClick={openFile} disabled={jobRunning}>
            Open File…
          </button>
          {gcodeLines.length > 0 && (
            <span className="run-line-count mono">{gcodeLines.length} lines</span>
          )}
        </div>
      </div>

      {/* Frame check — required before starting */}
      <FramePanel onFramePassed={() => setFramePassed(true)} />

      {/* Progress */}
      {gcodeLines.length > 0 && (
        <div className="run-section">
          <div className="run-section-header">
            <span className="label">Progress</span>
            <span className="label" style={{ color: 'var(--text-2)' }}>{jobProgress}%</span>
          </div>

          <div className="progress-bar-wrap">
            <div className="progress-bar-fill" style={{ width: `${jobProgress}%` }} />
          </div>

          <div className="run-line-info mono">
            Line {currentLine} / {gcodeLines.length}
          </div>
        </div>
      )}

      {/* Job controls */}
      {gcodeLines.length > 0 && (
        <div className="run-controls">
          {!jobRunning && !jobDone && (
            <button
              className="btn btn-amber run-start"
              onClick={startJob}
              disabled={!connected || !framePassed}
              title={!framePassed ? 'Run frame check first' : ''}
            >
              ▶ Start Job
            </button>
          )}
          {!framePassed && !jobRunning && (
            <span className="run-frame-gate">Run frame check above first</span>
          )}

          {jobRunning && !jobPaused && (
            <>
              <button className="btn run-ctrl-btn" onClick={pauseJob}>⏸ Pause</button>
              <button className="btn btn-red run-ctrl-btn" onClick={stopJob}>■ Stop</button>
            </>
          )}

          {jobRunning && jobPaused && (
            <>
              <button className="btn btn-amber run-ctrl-btn" onClick={resumeJob}>▶ Resume</button>
              <button className="btn btn-red run-ctrl-btn" onClick={stopJob}>■ Stop</button>
            </>
          )}

          {jobDone && (
            <div className="run-done">
              ✓ Job complete
              <button className="btn btn-sm" onClick={() => loadFile({ fileName, lines: gcodeLines })}>
                Reset
              </button>
            </div>
          )}
        </div>
      )}

      {/* Line preview */}
      {gcodeLines.length > 0 && jobRunning && (
        <div className="run-section">
          <span className="label">Current Line</span>
          <div className="line-preview">
            {linesBefore.map((l, i) => (
              <div key={i} className="line-preview-row line-prev">{l}</div>
            ))}
            <div className="line-preview-row line-current">
              <span className="line-arrow">▶</span>
              {currentLineText}
            </div>
            {linesAfter.map((l, i) => (
              <div key={i} className="line-preview-row line-next">{l}</div>
            ))}
          </div>
        </div>
      )}

      {/* Empty state */}
      {gcodeLines.length === 0 && (
        <div className="run-empty">
          <div className="run-empty-icon">⬡</div>
          <p>No file loaded</p>
          <p className="run-empty-sub">Open a .nc, .gcode, or .ngc file to begin</p>
        </div>
      )}
    </div>
  )
}
