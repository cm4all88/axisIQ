import { useEffect, useRef, useState } from 'react'
import { useMachineStore } from '../store'
import './VisualizeTab.css'

export default function VisualizeTab() {
  const { gcodeLines, currentLine, jobRunning, profile } = useMachineStore()
  const canvasRef = useRef(null)
  const stateRef = useRef({ pan: { x: 0, y: 0 }, zoom: 1, dragging: false, lastMouse: null })
  const [parsed, setParsed] = useState([])

  // Parse G-code into moves whenever file changes
  useEffect(() => {
    if (!gcodeLines.length) { setParsed([]); return }
    setParsed(parseGcode(gcodeLines))
  }, [gcodeLines])

  // Redraw whenever anything changes
  useEffect(() => {
    draw()
  }, [parsed, currentLine, jobRunning, profile])

  function draw() {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const { pan, zoom } = stateRef.current
    const W = canvas.width
    const H = canvas.height

    ctx.clearRect(0, 0, W, H)

    // Background
    ctx.fillStyle = '#17171a'
    ctx.fillRect(0, 0, W, H)

    if (!parsed.length) {
      ctx.fillStyle = '#36363e'
      ctx.font = '13px Inter Tight, sans-serif'
      ctx.textAlign = 'center'
      ctx.fillText('No file loaded', W / 2, H / 2)
      return
    }

    ctx.save()
    ctx.translate(pan.x, pan.y)
    ctx.scale(zoom, zoom)

    drawGrid(ctx, W, H, zoom, pan)
    drawWorkArea(ctx, profile)
    drawPaths(ctx, parsed, currentLine, jobRunning)
    drawOrigin(ctx)

    ctx.restore()
  }

  function drawGrid(ctx, W, H, zoom, pan) {
    const gridSize = 10
    const startX = Math.floor(-pan.x / zoom / gridSize) * gridSize
    const startY = Math.floor(-pan.y / zoom / gridSize) * gridSize
    const endX = startX + W / zoom + gridSize
    const endY = startY + H / zoom + gridSize

    ctx.strokeStyle = '#222228'
    ctx.lineWidth = 0.5 / zoom

    for (let x = startX; x <= endX; x += gridSize) {
      ctx.beginPath()
      ctx.moveTo(x, startY)
      ctx.lineTo(x, endY)
      ctx.stroke()
    }

    for (let y = startY; y <= endY; y += gridSize) {
      ctx.beginPath()
      ctx.moveTo(startX, y)
      ctx.lineTo(endX, y)
      ctx.stroke()
    }
  }

  function drawWorkArea(ctx, profile) {
    ctx.strokeStyle = '#36363e'
    ctx.lineWidth = 1
    ctx.setLineDash([4, 4])
    ctx.strokeRect(0, -profile.depth, profile.width, profile.depth)
    ctx.setLineDash([])
  }

  function drawPaths(ctx, moves, activeLine, running) {
    for (let i = 0; i < moves.length; i++) {
      const m = moves[i]
      if (!m.from) continue

      const done = running && i < activeLine
      const active = running && i === activeLine

      if (m.type === 'rapid') {
        ctx.strokeStyle = done ? '#3a3020' : active ? '#f0a030' : '#4a4820'
        ctx.setLineDash([3, 3])
        ctx.lineWidth = 0.8
      } else {
        ctx.strokeStyle = done ? '#604010' : active ? '#f0c060' : '#a06820'
        ctx.setLineDash([])
        ctx.lineWidth = 1.2
      }

      ctx.beginPath()
      ctx.moveTo(m.from.x, -m.from.y)

      if (m.type === 'arc') {
        drawArc(ctx, m)
      } else {
        ctx.lineTo(m.to.x, -m.to.y)
      }

      ctx.stroke()
    }

    ctx.setLineDash([])
  }

  function drawArc(ctx, m) {
    const cx = m.center.x
    const cy = -m.center.y
    const r = m.radius
    const startAngle = Math.atan2(-m.from.y - cy, m.from.x - cx)
    const endAngle = Math.atan2(-m.to.y - cy, m.to.x - cx)
    ctx.arc(cx, cy, r, startAngle, endAngle, m.ccw)
  }

  function drawOrigin(ctx) {
    ctx.lineWidth = 1
    ctx.strokeStyle = '#5ab878'
    ctx.beginPath(); ctx.moveTo(-8, 0); ctx.lineTo(8, 0); ctx.stroke()
    ctx.beginPath(); ctx.moveTo(0, -8); ctx.lineTo(0, 8); ctx.stroke()
    ctx.beginPath()
    ctx.arc(0, 0, 3, 0, Math.PI * 2)
    ctx.fillStyle = '#5ab878'
    ctx.fill()
  }

  // Auto-fit on new file
  useEffect(() => {
    if (!parsed.length || !canvasRef.current) return
    autoFit()
  }, [parsed])

  function autoFit() {
    const canvas = canvasRef.current
    if (!canvas || !parsed.length) return

    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity
    for (const m of parsed) {
      if (!m.to) continue
      minX = Math.min(minX, m.to.x, m.from?.x ?? m.to.x)
      maxX = Math.max(maxX, m.to.x, m.from?.x ?? m.to.x)
      minY = Math.min(minY, m.to.y, m.from?.y ?? m.to.y)
      maxY = Math.max(maxY, m.to.y, m.from?.y ?? m.to.y)
    }

    const W = canvas.width
    const H = canvas.height
    const padding = 60
    const rangeX = maxX - minX || 1
    const rangeY = maxY - minY || 1
    const zoom = Math.min((W - padding * 2) / rangeX, (H - padding * 2) / rangeY) * 0.9

    stateRef.current.zoom = zoom
    stateRef.current.pan = {
      x: W / 2 - (minX + rangeX / 2) * zoom,
      y: H / 2 + (minY + rangeY / 2) * zoom,
    }

    draw()
  }

  // Mouse events for pan/zoom
  function onWheel(e) {
    e.preventDefault()
    const s = stateRef.current
    const factor = e.deltaY < 0 ? 1.1 : 0.9
    const rect = canvasRef.current.getBoundingClientRect()
    const mx = e.clientX - rect.left
    const my = e.clientY - rect.top
    s.pan.x = mx - (mx - s.pan.x) * factor
    s.pan.y = my - (my - s.pan.y) * factor
    s.zoom *= factor
    draw()
  }

  function onMouseDown(e) {
    stateRef.current.dragging = true
    stateRef.current.lastMouse = { x: e.clientX, y: e.clientY }
  }

  function onMouseMove(e) {
    const s = stateRef.current
    if (!s.dragging) return
    s.pan.x += e.clientX - s.lastMouse.x
    s.pan.y += e.clientY - s.lastMouse.y
    s.lastMouse = { x: e.clientX, y: e.clientY }
    draw()
  }

  function onMouseUp() { stateRef.current.dragging = false }

  return (
    <div className="visualize-tab">
      <div className="viz-toolbar">
        <button className="btn btn-sm" onClick={autoFit}>Fit View</button>
        <span className="viz-hint">Scroll to zoom · Drag to pan</span>
        {jobRunning && (
          <span className="viz-progress">
            Line {currentLine} / {gcodeLines.length}
          </span>
        )}
      </div>
      <canvas
        ref={canvasRef}
        className="viz-canvas"
        width={1200}
        height={800}
        onWheel={onWheel}
        onMouseDown={onMouseDown}
        onMouseMove={onMouseMove}
        onMouseUp={onMouseUp}
        onMouseLeave={onMouseUp}
      />
    </div>
  )
}

// — G-code parser ——————————————————————————————————————

function parseGcode(lines) {
  const moves = []
  let pos = { x: 0, y: 0, z: 0 }
  let absolute = true
  let modal = 'G1' // current motion mode

  for (const raw of lines) {
    const line = raw.split(';')[0].toUpperCase().trim()
    if (!line) continue

    // Modal updates
    if (line.includes('G90')) absolute = true
    if (line.includes('G91')) absolute = false
    if (line.includes('G0')) modal = 'G0'
    if (line.includes('G1')) modal = 'G1'

    const g = extractCode(line, 'G')
    const mode = g !== null ? `G${g}` : modal

    if (![0, 1, 2, 3].includes(g) && g !== null) continue

    const nx = extractVal(line, 'X')
    const ny = extractVal(line, 'Y')
    const nz = extractVal(line, 'Z')
    const ii = extractVal(line, 'I')
    const jj = extractVal(line, 'J')

    if (nx === null && ny === null && nz === null) continue

    const from = { ...pos }
    const to = {
      x: absolute ? (nx ?? pos.x) : pos.x + (nx ?? 0),
      y: absolute ? (ny ?? pos.y) : pos.y + (ny ?? 0),
      z: absolute ? (nz ?? pos.z) : pos.z + (nz ?? 0),
    }

    if (mode === 'G0') {
      moves.push({ type: 'rapid', from, to })
    } else if (mode === 'G1') {
      moves.push({ type: 'cut', from, to })
    } else if (mode === 'G2' || mode === 'G3') {
      const cx = from.x + (ii ?? 0)
      const cy = from.y + (jj ?? 0)
      const radius = Math.sqrt((from.x - cx) ** 2 + (from.y - cy) ** 2)
      moves.push({
        type: 'arc',
        from, to,
        center: { x: cx, y: cy },
        radius,
        ccw: mode === 'G3',
      })
    }

    pos = to
  }

  return moves
}

function extractCode(line, letter) {
  const m = line.match(new RegExp(letter + '(\\d+\\.?\\d*)'))
  return m ? parseFloat(m[1]) : null
}

function extractVal(line, letter) {
  const m = line.match(new RegExp(letter + '(-?\\d+\\.?\\d*)'))
  return m ? parseFloat(m[1]) : null
}
