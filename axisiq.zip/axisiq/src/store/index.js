import { create } from 'zustand'

const DEFAULT_ROUTER_PROFILE = {
  name: 'My Router',
  type: 'router',
  width: 800,
  depth: 400,
  height: 100,
  maxFeed: 5000,
  maxSpindle: 24000,
}

const DEFAULT_LASER_PROFILE = {
  name: 'My CO2 Laser',
  type: 'co2',
  width: 600,
  depth: 400,
  height: 200,
  tubePower: 60,       // watts
  maxSpeed: 500,       // mm/s
  maxSValue: 1000,     // GRBL $30
  focusHeight: 50,     // mm
}

// Convert 0-100% to GRBL S value
export const pctToS = (pct, maxS = 1000) => Math.round(pct / 100 * maxS)
// Convert mm/s to mm/min
export const mmsMmm = (mms) => Math.round(mms * 60)

export const useMachineStore = create((set, get) => ({
  // — Machine type ————————————————————————————————————
  machineType: 'router',   // 'router' | 'co2'
  setMachineType: (t) => set({ machineType: t }),

  // — Connection ——————————————————————————————————————
  ports: [],
  selectedPort: '',
  baudRate: 115200,
  connected: false,
  firmware: '',

  setPortList: (ports) => set({ ports }),
  setSelectedPort: (p) => set({ selectedPort: p }),
  setBaudRate: (b) => set({ baudRate: b }),
  setConnected: (v, firmware = '') => set({ connected: v, firmware }),
  setDisconnected: () => set({
    connected: false, firmware: '',
    machineState: 'Disconnected',
    position: { x: 0, y: 0, z: 0 },
    feedRate: 0, spindleSpeed: 0,
  }),

  // — Machine state ———————————————————————————————————
  machineState: 'Disconnected', // Idle | Run | Hold | Alarm | Home | Check | Door | Sleep | Disconnected
  position: { x: 0, y: 0, z: 0 },
  machinePos: { x: 0, y: 0, z: 0 },
  feedRate: 0,
  spindleSpeed: 0,
  overrides: { feed: 100, rapid: 100, spindle: 100 },

  applyStatus: (status) => {
    const updates = { machineState: status.state }
    if (status.wpos) updates.position = status.wpos
    else if (status.mpos) updates.machinePos = status.mpos
    if (status.fs) {
      updates.feedRate = status.fs.feed
      updates.spindleSpeed = status.fs.spindle
    }
    if (status.ov) updates.overrides = {
      feed: status.ov.feed,
      rapid: status.ov.rapid,
      spindle: status.ov.spindle,
    }
    set(updates)
  },

  // — Jog ————————————————————————————————————————————
  jogStep: 1,
  jogFeed: 1000,
  units: 'mm',

  setJogStep: (v) => set({ jogStep: v }),
  setJogFeed: (v) => set({ jogFeed: v }),
  setUnits: (v) => set({ units: v }),

  // — Job ————————————————————————————————————————————
  fileName: null,
  gcodeLines: [],
  currentLine: 0,
  jobRunning: false,
  jobPaused: false,
  jobDone: false,
  jobProgress: 0,

  loadFile: ({ fileName, lines }) => set({
    fileName,
    gcodeLines: lines,
    currentLine: 0,
    jobProgress: 0,
    jobRunning: false,
    jobPaused: false,
    jobDone: false,
  }),

  setJobRunning: () => set({ jobRunning: true, jobPaused: false, jobDone: false }),
  setJobPaused: () => set({ jobPaused: true }),
  setJobResumed: () => set({ jobPaused: false }),
  setJobStopped: () => set({ jobRunning: false, jobPaused: false, currentLine: 0, jobProgress: 0 }),
  setJobDone: () => set({ jobRunning: false, jobDone: true }),
  updateProgress: ({ current, total }) => set({
    currentLine: current,
    jobProgress: total > 0 ? Math.round((current / total) * 100) : 0,
  }),

  // — Console log ————————————————————————————————————
  consoleLog: [],
  addLog: (entry) => set((s) => ({
    consoleLog: [...s.consoleLog.slice(-499), entry]
  })),
  clearLog: () => set({ consoleLog: [] }),

  // — Profile ————————————————————————————————————————
  profile: DEFAULT_ROUTER_PROFILE,
  laserProfile: DEFAULT_LASER_PROFILE,
  setProfile: (p) => set({ profile: p }),
  setLaserProfile: (p) => set({ laserProfile: p }),

  // — Laser controls —————————————————————————————————
  laserPower: 80,          // %
  laserSpeed: 200,         // mm/s
  laserPasses: 1,
  laserFocus: 50,          // mm (Z height)
  laserMode: 'dynamic',    // 'constant' | 'dynamic' (M3 vs M4)
  airAssist: false,
  fireWatchMins: 10,

  setLaserPower:  (v) => set({ laserPower: v }),
  setLaserSpeed:  (v) => set({ laserSpeed: v }),
  setLaserPasses: (v) => set({ laserPasses: v }),
  setLaserFocus:  (v) => set({ laserFocus: v }),
  setLaserMode:   (v) => set({ laserMode: v }),
  setAirAssist:   (v) => set({ airAssist: v }),
  setFireWatch:   (v) => set({ fireWatchMins: v }),

  // — Active material ————————————————————————————————
  activeMaterial: null,
  setActiveMaterial: (m) => set({ activeMaterial: m }),

  // — Active tab ————————————————————————————————————
  activeTab: 'run',
  setActiveTab: (t) => set({ activeTab: t }),
}))
