import { useEffect, useRef } from 'react'
import { useMachineStore } from './store'
import Sidebar from './components/Sidebar'
import LaserSidebar from './components/LaserSidebar'
import MainPanel from './components/MainPanel'
import TopBar from './components/TopBar'
import './App.css'

const api = window.axisiq

export default function App() {
  const {
    connected, setConnected, setDisconnected,
    applyStatus, addLog, updateProgress,
    setJobDone, activeTab, machineType,
  } = useMachineStore()

  const pollRef = useRef(null)

  // Wire up all IPC event listeners once
  useEffect(() => {
    if (!api) return

    const unsubs = [
      api.on('serial:log', (entry) => addLog(entry)),

      api.on('serial:connected', ({ firmware }) => {
        setConnected(true, firmware)
        addLog({ type: 'info', text: `Firmware: ${firmware}`, time: Date.now() })
      }),

      api.on('serial:disconnected', () => {
        setDisconnected()
        stopPoll()
      }),

      api.on('serial:status', (status) => {
        applyStatus(status)
      }),

      api.on('serial:alarm', ({ code }) => {
        addLog({ type: 'error', text: `⚠ ${code}`, time: Date.now() })
      }),

      api.on('stream:progress', (data) => updateProgress(data)),

      api.on('stream:done', () => {
        setJobDone()
        addLog({ type: 'info', text: 'Job complete', time: Date.now() })
      }),

      api.on('stream:error', ({ line, message }) => {
        addLog({ type: 'error', text: `Line ${line}: ${message}`, time: Date.now() })
      }),
    ]

    return () => unsubs.forEach(u => u && u())
  }, [])

  // Start/stop status polling when connection changes
  useEffect(() => {
    if (connected) {
      startPoll()
    } else {
      stopPoll()
    }
    return () => stopPoll()
  }, [connected])

  function startPoll() {
    if (pollRef.current) return
    pollRef.current = setInterval(() => {
      api?.poll()
    }, 250)
  }

  function stopPoll() {
    if (pollRef.current) {
      clearInterval(pollRef.current)
      pollRef.current = null
    }
  }

  return (
    <div className="app-shell">
      <TopBar />
      <div className="app-body">
        {machineType === 'co2' ? <LaserSidebar /> : <Sidebar />}
        <MainPanel />
      </div>
    </div>
  )
}
