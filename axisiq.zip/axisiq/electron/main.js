const { app, BrowserWindow, ipcMain, dialog } = require('electron')
const path = require('path')
const { SerialPort } = require('serialport')
const { ReadlineParser } = require('@serialport/parser-readline')
const fs = require('fs')

const isDev = process.env.NODE_ENV === 'development' || !app.isPackaged

let mainWindow = null
let port = null
let parser = null
let streamQueue = []
let isStreaming = false
let streamPaused = false
let streamLineIndex = 0
let okCount = 0
let streamLines = []

// — Window ——————————————————————————————————————————————

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#18181a',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  })

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173')
    mainWindow.webContents.openDevTools({ mode: 'detach' })
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'))
  }

  mainWindow.on('closed', () => {
    if (port && port.isOpen) port.close()
    mainWindow = null
  })
}

app.whenReady().then(createWindow)
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit() })
app.on('activate', () => { if (!mainWindow) createWindow() })

// — Helpers ————————————————————————————————————————————

function send(channel, data) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send(channel, data)
  }
}

function log(type, text) {
  send('serial:log', { type, text, time: Date.now() })
}

// — Serial port IPC ————————————————————————————————————

ipcMain.handle('serial:list', async () => {
  const ports = await SerialPort.list()
  return ports.map(p => ({
    path: p.path,
    manufacturer: p.manufacturer || '',
    serialNumber: p.serialNumber || '',
    pnpId: p.pnpId || '',
  }))
})

ipcMain.handle('serial:connect', async (_, { path: portPath, baudRate = 115200 }) => {
  if (port && port.isOpen) {
    port.close()
    port = null
    parser = null
  }

  return new Promise((resolve) => {
    port = new SerialPort({ path: portPath, baudRate, autoOpen: false })
    parser = port.pipe(new ReadlineParser({ delimiter: '\n' }))

    parser.on('data', (line) => {
      const trimmed = line.trim()
      if (!trimmed) return

      log('recv', trimmed)

      // Grbl status response
      if (trimmed.startsWith('<') && trimmed.endsWith('>')) {
        send('serial:status', parseGrblStatus(trimmed))
        return
      }

      // Startup message
      if (trimmed.startsWith('Grbl') || trimmed.startsWith('GRBL')) {
        send('serial:connected', { firmware: trimmed })
        return
      }

      // Stream acknowledgement
      if (trimmed === 'ok' || trimmed.startsWith('error:')) {
        if (isStreaming && !streamPaused) {
          if (trimmed.startsWith('error:')) {
            send('stream:error', { line: streamLineIndex, message: trimmed })
          }
          okCount++
          send('stream:progress', { current: okCount, total: streamLines.length })
          if (okCount >= streamLines.length) {
            finishStream()
          } else {
            sendNextStreamLine()
          }
        }
        return
      }

      // Alarm
      if (trimmed.startsWith('ALARM:')) {
        send('serial:alarm', { code: trimmed })
      }
    })

    port.open((err) => {
      if (err) {
        log('error', `Failed to open: ${err.message}`)
        resolve({ success: false, error: err.message })
        return
      }
      log('info', `Connected to ${portPath} at ${baudRate} baud`)
      // Request Grbl version
      setTimeout(() => rawSend('\r\n'), 500)
      resolve({ success: true })
    })

    port.on('error', (err) => {
      log('error', err.message)
      send('serial:disconnected', {})
    })

    port.on('close', () => {
      log('info', 'Port closed')
      send('serial:disconnected', {})
      isStreaming = false
      streamPaused = false
    })
  })
})

ipcMain.handle('serial:disconnect', async () => {
  if (port && port.isOpen) {
    port.close()
  }
  return { success: true }
})

ipcMain.handle('serial:send', async (_, { command }) => {
  if (!port || !port.isOpen) return { success: false, error: 'Not connected' }
  rawSend(command)
  log('sent', command)
  return { success: true }
})

// Real-time commands bypass log (too frequent)
ipcMain.handle('serial:realtime', async (_, { byte }) => {
  if (!port || !port.isOpen) return
  port.write(Buffer.from([byte]))
})

// Status poll — renderer calls this on a timer
ipcMain.handle('serial:poll', async () => {
  if (!port || !port.isOpen) return
  port.write('?')
})

// — File handling ———————————————————————————————————————

ipcMain.handle('file:open', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Open G-code File',
    filters: [
      { name: 'G-code', extensions: ['nc', 'gcode', 'ngc', 'gc', 'cnc', 'tap'] },
      { name: 'All Files', extensions: ['*'] },
    ],
    properties: ['openFile'],
  })
  if (result.canceled) return { canceled: true }
  const filePath = result.filePaths[0]
  const content = fs.readFileSync(filePath, 'utf-8')
  const lines = content.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith(';') && !l.startsWith('%'))
  return { canceled: false, filePath, fileName: path.basename(filePath), lines, raw: content }
})

// — Streaming ——————————————————————————————————————————

ipcMain.handle('stream:start', async (_, { lines }) => {
  if (!port || !port.isOpen) return { success: false, error: 'Not connected' }
  streamLines = lines
  streamLineIndex = 0
  okCount = 0
  isStreaming = true
  streamPaused = false
  log('info', `Starting job: ${lines.length} lines`)
  sendNextStreamLine()
  return { success: true }
})

ipcMain.handle('stream:pause', async () => {
  if (!port || !port.isOpen) return
  streamPaused = true
  port.write('!')  // Grbl feed hold
  log('info', 'Feed hold')
})

ipcMain.handle('stream:resume', async () => {
  if (!port || !port.isOpen) return
  streamPaused = false
  port.write('~')  // Grbl cycle start
  log('info', 'Resumed')
  sendNextStreamLine()
})

ipcMain.handle('stream:stop', async () => {
  isStreaming = false
  streamPaused = false
  streamLines = []
  streamLineIndex = 0
  okCount = 0
  if (port && port.isOpen) {
    port.write(Buffer.from([0x18]))  // Grbl soft reset
    log('info', 'Job stopped — soft reset sent')
  }
})

function sendNextStreamLine() {
  if (!isStreaming || streamPaused) return
  if (streamLineIndex >= streamLines.length) return
  const line = streamLines[streamLineIndex]
  rawSend(line)
  send('stream:current-line', { index: streamLineIndex, line })
  streamLineIndex++
}

function finishStream() {
  isStreaming = false
  log('info', 'Job complete')
  send('stream:done', {})
}

function rawSend(text) {
  if (!port || !port.isOpen) return
  const cmd = text.endsWith('\n') ? text : text + '\n'
  port.write(cmd)
}

// — Laser-specific IPC ————————————————————————————————

ipcMain.handle('laser:enable', async () => {
  // Enable GRBL laser mode ($32=1) and set max S value
  rawSend('$32=1')
  rawSend('$30=1000')
  log('info', 'Laser mode enabled ($32=1, $30=1000)')
})

ipcMain.handle('laser:disable', async () => {
  rawSend('$32=0')
  log('info', 'Laser mode disabled ($32=0)')
})

ipcMain.handle('laser:on', async (_, { power, dynamic }) => {
  // power: 0-100%, converts to 0-1000 S value
  const S = Math.round(power / 100 * 1000)
  const cmd = dynamic ? `M4 S${S}` : `M3 S${S}`
  rawSend(cmd)
  log('info', `Laser on: ${power}% (S${S}) ${dynamic ? 'M4' : 'M3'}`)
})

ipcMain.handle('laser:off', async () => {
  rawSend('M5')
  log('info', 'Laser off')
})

ipcMain.handle('laser:test-fire', async (_, { power, durationMs }) => {
  const S = Math.round(power / 100 * 1000)
  rawSend(`M3 S${S}`)
  setTimeout(() => rawSend('M5'), durationMs || 200)
  log('info', `Test fire: ${power}% for ${durationMs || 200}ms`)
})

ipcMain.handle('laser:air-on', async () => {
  rawSend('M8')
  log('info', 'Air assist ON')
})

ipcMain.handle('laser:air-off', async () => {
  rawSend('M9')
  log('info', 'Air assist OFF')
})

ipcMain.handle('laser:set-focus', async (_, { height }) => {
  rawSend(`G0 Z${height.toFixed(3)}`)
  log('info', `Focus height: Z${height}mm`)
})

// — Time lapse ——————————————————————————————————————————
// Renderer sends individual JPEG blobs; main compiles with FFmpeg

ipcMain.handle('timelapse:compile', async (_, { frameCount }) => {
  log('info', `Time lapse compile requested: ${frameCount} frames`)
  // Full implementation: collect frame paths written by renderer via IPC,
  // then shell out to bundled ffmpeg binary:
  //   ffmpeg -r 24 -i frame%04d.jpg -vcodec libx264 -pix_fmt yuv420p output.mp4
  // For now, open save dialog so user can choose output path
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'Save Time Lapse',
    defaultPath: `axisiq-timelapse-${Date.now()}.mp4`,
    filters: [{ name: 'Video', extensions: ['mp4'] }],
  })
  if (!result.canceled) {
    log('info', `Time lapse would be saved to: ${result.filePath}`)
    send('timelapse:compile-done', { path: result.filePath })
  }
  return { success: !result.canceled, path: result.filePath }
})
// Parses: <Idle|MPos:0.000,0.000,0.000|WPos:0.000,0.000,0.000|FS:0,0|Ov:100,100,100>

function parseGrblStatus(raw) {
  const inner = raw.slice(1, -1)
  const parts = inner.split('|')
  const state = parts[0]

  const result = { state, mpos: null, wpos: null, fs: null, ov: null }

  for (let i = 1; i < parts.length; i++) {
    const [key, val] = parts[i].split(':')
    if (!val) continue
    const nums = val.split(',').map(Number)

    if (key === 'MPos') result.mpos = { x: nums[0], y: nums[1], z: nums[2] }
    else if (key === 'WPos') result.wpos = { x: nums[0], y: nums[1], z: nums[2] }
    else if (key === 'FS') result.fs = { feed: nums[0], spindle: nums[1] }
    else if (key === 'Ov') result.ov = { feed: nums[0], rapid: nums[1], spindle: nums[2] }
  }

  return result
}
