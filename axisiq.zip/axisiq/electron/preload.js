const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('axisiq', {
  // Serial port
  listPorts:    ()       => ipcRenderer.invoke('serial:list'),
  connect:      (opts)   => ipcRenderer.invoke('serial:connect', opts),
  disconnect:   ()       => ipcRenderer.invoke('serial:disconnect'),
  send:         (cmd)    => ipcRenderer.invoke('serial:send', { command: cmd }),
  realtime:     (byte)   => ipcRenderer.invoke('serial:realtime', { byte }),
  poll:         ()       => ipcRenderer.invoke('serial:poll'),

  // File
  openFile:     ()       => ipcRenderer.invoke('file:open'),

  // Streaming
  startStream:  (lines)  => ipcRenderer.invoke('stream:start', { lines }),
  pauseStream:  ()       => ipcRenderer.invoke('stream:pause'),
  resumeStream: ()       => ipcRenderer.invoke('stream:resume'),
  stopStream:   ()       => ipcRenderer.invoke('stream:stop'),

  // Laser
  laserEnable:    ()           => ipcRenderer.invoke('laser:enable'),
  laserDisable:   ()           => ipcRenderer.invoke('laser:disable'),
  laserOn:        (opts)       => ipcRenderer.invoke('laser:on', opts),
  laserOff:       ()           => ipcRenderer.invoke('laser:off'),
  laserTestFire:  (opts)       => ipcRenderer.invoke('laser:test-fire', opts),
  airOn:          ()           => ipcRenderer.invoke('laser:air-on'),
  airOff:         ()           => ipcRenderer.invoke('laser:air-off'),
  setFocus:       (h)          => ipcRenderer.invoke('laser:set-focus', { height: h }),

  // Events
  on: (channel, cb) => {
    const allowed = [
      'serial:log', 'serial:status', 'serial:connected', 'serial:disconnected',
      'serial:alarm', 'stream:progress', 'stream:current-line', 'stream:done', 'stream:error',
    ]
    if (!allowed.includes(channel)) return
    const listener = (_, data) => cb(data)
    ipcRenderer.on(channel, listener)
    return () => ipcRenderer.removeListener(channel, listener)
  },
})
