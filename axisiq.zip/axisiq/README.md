# AxisIQ

CNC control software by Tahoma Systems. Desktop-first, works offline, optional AI assist.

Built on Electron + React/Vite. Targets GRBL-based machines (wood routers, mills, plasma) with a clean modern interface over Mach3-era UX.

---

## Setup

```bash
npm install
```

**Note:** `serialport` requires native compilation. If you hit errors:

```bash
npm install --build-from-source
# or, if using electron-rebuild:
npx electron-rebuild
```

---

## Development

```bash
npm run dev
```

This runs Vite (renderer) and Electron concurrently. Hot reload works for the React UI. Electron main process requires a restart on changes.

---

## Build (distributable)

```bash
npm run build
```

Output goes to `dist-electron/`. Produces `.exe` (Windows), `.dmg` (Mac), or `.AppImage` (Linux) depending on platform.

---

## Architecture

```
electron/
  main.js       — Main process. Serial port, IPC handlers, file dialogs, G-code streaming.
  preload.js    — Context bridge. Exposes window.axisiq API to the renderer.

src/
  store/        — Zustand global state (machine, job, UI)
  components/
    TopBar        — App header, E-stop button
    Sidebar       — Connection, position readout, jog controls
    MainPanel     — Tab container
    RunTab        — File load, job run, progress
    VisualizeTab  — Canvas 2D toolpath preview with pan/zoom
    ConsoleTab    — G-code terminal, quick commands
    SetupTab      — Machine profile, work offsets, GRBL commands
    AIPanel       — Anthropic-powered CNC assistant
```

---

## Machine compatibility

Designed for **GRBL 1.1** (the standard firmware on most hobby/prosumer CNC routers). Communicates over serial at 115200 baud by default.

Mach3/Mach4 support is on the roadmap (v2) — the streaming architecture is compatible, just needs a different protocol layer.

### Tested controllers
- GRBL on Arduino Uno/Mega
- GRBL on xPro v4/v5
- BlackBox (OpenBuilds)

---

## AI Assist

Uses the Anthropic API directly from the desktop app. Your API key is stored in localStorage and never leaves your machine except in direct API calls to Anthropic.

Set your key in the AI Assist tab (🔑 button). The assistant has full context of your machine profile, current state, and loaded G-code.

---

## Keyboard shortcuts (Jog)

Active when the Console input is not focused:

| Key | Action |
|-----|--------|
| Arrow Left/Right | Jog X |
| Arrow Up/Down | Jog Y |
| Page Up/Down | Jog Z |

Step size and feed rate are set in the Jog panel.

---

## License

© Tahoma Systems LLC. All rights reserved.
